package logica;

public class Reserva {

	private int personas;
	private double precio;
	private int duracion;
	private String nombre;
	private String tipo;
	private double precioAdulto;
	private double precioNi�o;
	private String codigo;
	private int adultos;
	private int ni�os;
	private String observaciones;
	private String fechaInicio;
	private boolean desayuno;

	public Reserva(String codigo, int personas, double precio, String fechaInicio, int duracion, String nombre,
			String tipo, double adulto, double ni�o, int adultos, int ni�os, String observaciones, boolean desayuno) {
		super();
		this.setDesayuno(desayuno);
		this.codigo = codigo;
		this.personas = personas;
		this.precio = precio;
		this.duracion = duracion;
		this.nombre = nombre;
		this.tipo = tipo;
		this.precioAdulto = adulto;
		this.precioNi�o = ni�o;
		this.adultos = adultos;
		this.ni�os = ni�os;
		this.observaciones = observaciones;
		this.fechaInicio = fechaInicio;

	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public int getAdultos() {
		return adultos;
	}

	public void setAdultos(int adultos) {
		this.adultos = adultos;
	}

	public int getNi�os() {
		return ni�os;
	}

	public void setNi�os(int ni�os) {
		this.ni�os = ni�os;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public int getPersonas() {
		return personas;
	}

	public void setPersonas(int personas) {
		this.personas = personas;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipo() {
		return tipo;
	}

	public double getPrecioAdulto() {
		return precioAdulto;
	}

	public void setPrecioAdulto(double precioAdulto) {
		this.precioAdulto = precioAdulto;
	}

	public double getPrecioNi�o() {
		return precioNi�o;
	}

	public void setPrecioNi�o(double precioNi�o) {
		this.precioNi�o = precioNi�o;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCodigo() {
		return codigo;
	}

	public boolean isDesayuno() {
		return desayuno;
	}

	public void setDesayuno(boolean desayuno) {
		this.desayuno = desayuno;
	}

}