package logica;

public class Alojamiento {

	private String codigo;
	private String tipo;
	private String categoria;
	private String denominacion;
	private String codigo_parque;
	private int plazas;
	private double precio;

	public Alojamiento(String codigo, String tipo, String categoria, String denominacion, String codigo_parque,
			int plazas, double precio) {
		super();
		this.codigo = codigo;
		this.tipo = tipo;
		this.categoria = categoria;
		this.denominacion = denominacion;
		this.codigo_parque = codigo_parque;
		this.plazas = plazas;
		this.precio = precio;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDenominacion() {
		return denominacion;
	}

	public void setDenominacion(String denominacion) {
		this.denominacion = denominacion;
	}

	public String getCodigo_parque() {
		return codigo_parque;
	}

	public void setCodigo_parque(String codigo_parque) {
		this.codigo_parque = codigo_parque;
	}

	public int getPlazas() {
		return plazas;
	}

	public void setPlazas(int plazas) {
		this.plazas = plazas;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

}
