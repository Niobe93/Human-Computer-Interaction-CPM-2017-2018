package logica;

public class Entrada {

	private String codigo;
	private String codigo_parque;
	private double precio_adulto;
	private double precio_ni�o;

	public Entrada(String codigo, String codigo_parque, double precio_adulto, double precio_ni�o) {
		super();
		this.codigo = codigo;
		this.codigo_parque = codigo_parque;
		this.precio_adulto = precio_adulto;
		this.precio_ni�o = precio_ni�o;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigo_parque() {
		return codigo_parque;
	}

	public void setCodigo_parque(String codigo_parque) {
		this.codigo_parque = codigo_parque;
	}

	public double getPrecio_adulto() {
		return precio_adulto;
	}

	public void setPrecio_adulto(double precio_adulto) {
		this.precio_adulto = precio_adulto;
	}

	public double getPrecio_ni�o() {
		return precio_ni�o;
	}

	public void setPrecio_ni�o(double precio_ni�o) {
		this.precio_ni�o = precio_ni�o;
	}

}
