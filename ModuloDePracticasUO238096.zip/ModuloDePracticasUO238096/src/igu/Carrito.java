package igu;

import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import logica.Agencia;
import logica.Reserva;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Carrito extends JDialog {

	private static final long serialVersionUID = 1L;
	private JScrollPane scrollPane;
	private JButton btnCerrar;
	private VentanaPrincipal VP;
	private ArrayList<Reserva> reservados;
	private JPanel panel_carrito;
	private JButton btnNewButton;
	private Agencia agencia;
	FacturaVentana factura;

	public Carrito(VentanaPrincipal Vp, Agencia agencia) {
		setResizable(false);
		getContentPane().setBackground(Color.WHITE);
		this.agencia = agencia;
		this.VP = Vp;
		reservados = new ArrayList<Reserva>();
		setIconImage(Toolkit.getDefaultToolkit().getImage(Carrito.class.getResource("/img/logo.jpg")));
		setBounds(100, 100, 583, 449);
		setTitle("Cesta de la compra");
		getContentPane().setLayout(null);
		getContentPane().add(getScrollPane());
		getContentPane().add(getBtnCerrar());
		getContentPane().add(getBtnNewButton());

	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPane.setViewportBorder(null);
			scrollPane.setBounds(10, 23, 557, 332);
			scrollPane.setViewportView(getPanel_carrito());
		}
		return scrollPane;
	}

	private JButton getBtnCerrar() {
		if (btnCerrar == null) {
			btnCerrar = new JButton("Cerrar");
			btnCerrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnCerrar.setToolTipText("Cerrar el carrito");
			btnCerrar.setMnemonic('C');

			btnCerrar.setBounds(478, 386, 89, 23);
		}
		return btnCerrar;
	}

	public void a�adirCarrito(Reserva reserva, JPanel panel) {

		reservados.add(reserva);
		panel_carrito.add(panel);
		JOptionPane.showMessageDialog(null, "Reserva realizada con �xito", "�xito!", JOptionPane.INFORMATION_MESSAGE);

	}
	
	
	public String pintarCarrito() {
		String articulosCarrito = "";
		for (int i = 0; i < reservados.size(); i++) {
			articulosCarrito += ("Reserva: " + reservados.get(i).getNombre());
		}
		return articulosCarrito;
	}

	private JPanel getPanel_carrito() {
		if (panel_carrito == null) {
			panel_carrito = new JPanel();
			panel_carrito.setBackground(Color.WHITE);
		}
		return panel_carrito;
	}

	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("Confirmar compra");
			btnNewButton.setMnemonic('P');
			btnNewButton.setToolTipText("Confirmar las reservas realizas y continuar con el pago");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					facturaVentana();
				}
			});
			btnNewButton.setBounds(325, 386, 130, 23);
		}
		return btnNewButton;
	}

	void facturaVentana() {
		factura = new FacturaVentana(agencia, reservados, this);
		factura.setLocationRelativeTo(null);
		factura.setVisible(true);
	}

	public void inicializar() {
		this.removeAll();
		VP.inicializar();
		dispose();

	}

}
