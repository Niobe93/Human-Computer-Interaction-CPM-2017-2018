package igu;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import logica.Agencia;
import logica.Reserva;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Justificante extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Agencia agencia;
	private ArrayList<Reserva> reservados;
	private String nombre;
	private String dni;
	private Carrito carrito;

	/**
	 * Create the dialog.
	 * 
	 * @param dni
	 * @param nombre
	 * @param reservados
	 * @param carrito
	 * @param agencia
	 */
	public Justificante(Agencia agencia, Carrito carrito, ArrayList<Reserva> reservados, String nombre, String dni) {
		this.agencia = agencia;
		this.carrito = carrito;
		this.reservados = reservados;
		this.nombre = nombre;
		this.dni = dni;
		setBackground(Color.WHITE);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Justificante.class.getResource("/img/logo.jpg")));
		setTitle("Justificante de compra");
		setModal(true);
		setBounds(100, 100, 581, 361);
		getContentPane().setLayout(new BorderLayout());
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(Color.WHITE);
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setToolTipText("Termina la operacion");
				okButton.setMnemonic('K');
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						carrito.inicializar();
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
		{
			JScrollPane scrollPane = new JScrollPane();
			getContentPane().add(scrollPane, BorderLayout.CENTER);
			{
				JTextArea textArea = new JTextArea();
				textArea.setFont(new Font("Times New Roman", Font.PLAIN, 13));
				textArea.setWrapStyleWord(true);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
				textArea.setText(agencia.getFactura(nombre, dni, reservados));
				scrollPane.setViewportView(textArea);
			}
		}
	}

	public Agencia getAgencia() {
		return agencia;
	}

	public ArrayList<Reserva> getReservados() {
		return reservados;
	}

	public String getNombre() {
		return nombre;
	}

	public String getDni() {
		return dni;
	}

	public Carrito getCarrito() {
		return carrito;
	}

}
