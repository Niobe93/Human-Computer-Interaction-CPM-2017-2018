package igu;

import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.border.SoftBevelBorder;
import logica.Reserva;

import javax.swing.border.BevelBorder;
import java.awt.Color;

import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.border.TitledBorder;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class ReservaAlojamientoJpane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Reserva alojamiento;
	private JPanel panel;
	private JPanel panel_nombre;
	private JPanel panel_precio;
	private JPanel panel_personas;
	private JLabel lblNmeroDePersonas;
	private JSpinner spinner;
	private JLabel lblNombre;
	private JLabel lblPrecio;
	private JLabel lblNewLabel;
	private JPanel panel_observaciones;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	@SuppressWarnings("unused")
	private Carrito carrito;
	private JPanel panel_desayuno;
	private JCheckBox desayuno;
	/**
	 * Create the panel.
	 */
	public ReservaAlojamientoJpane(Reserva alojamiento, Carrito carrito) {
		this.alojamiento = alojamiento;

		this.carrito = carrito;
		setBackground(new Color(255, 255, 255));
		setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.DARK_GRAY, null, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		add(getPanel());
		alojamiento.setAdultos((int) spinner.getValue());
		alojamiento.setObservaciones(getTextArea().getText());
		calcularPrecio((int) spinner.getValue(), alojamiento.getDuracion());

	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBorder(new EmptyBorder(0, 0, 0, 0));
			panel.setBackground(Color.WHITE);
			panel.setLayout(new GridLayout(0, 1, 2, 2));
			panel.add(getPanel_nombre());
			panel.add(getPanel_personas());
			panel.add(getPanel_precio());
			panel.add(getPanel_desayuno());
			panel.add(getPanel_observaciones());

		}
		return panel;
	}

	private JPanel getPanel_nombre() {
		if (panel_nombre == null) {
			panel_nombre = new JPanel();
			panel_nombre.setBackground(Color.WHITE);
			panel_nombre.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));

			panel_nombre.add(getLblNombre());
		}
		return panel_nombre;
	}

	private JSpinner getSpinner() {
		if (spinner == null) {
			spinner = new JSpinner();
			spinner.setToolTipText("Selecciona el numero de personas. Algunos alojamientos tienen plazas limitadas.");
			spinner.setModel(new SpinnerNumberModel(1, 1, alojamiento.getPersonas(), 1));
			spinner.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					calcularPrecio((int) spinner.getValue(), alojamiento.getDuracion());
					alojamiento.setAdultos((int) spinner.getValue());
				}
			});
			spinner.setForeground(Color.WHITE);
		}
		return spinner;
	}

	private JPanel getPanel_precio() {
		if (panel_precio == null) {
			panel_precio = new JPanel();
			panel_precio.setForeground(Color.BLACK);
			panel_precio.setBackground(Color.WHITE);
			panel_precio.add(getLblNewLabel());

			panel_precio.add(getLblPrecio());
		}
		return panel_precio;
	}

	private JPanel getPanel_personas() {
		if (panel_personas == null) {
			panel_personas = new JPanel();
			panel_personas.setBackground(Color.WHITE);
			panel_personas.add(getLblNmeroDePersonas());
			panel_personas.add(getSpinner());

		}
		return panel_personas;
	}

	private JLabel getLblNmeroDePersonas() {
		if (lblNmeroDePersonas == null) {
			lblNmeroDePersonas = new JLabel("N\u00FAmero de personas");
			lblNmeroDePersonas.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return lblNmeroDePersonas;
	}

	public void calcularPrecio(int personas, int dias) {
		if (alojamiento.getTipo().equals("HO")) {
			if (getDesayuno().isSelected()) {
				getLblPrecio().setText(String.valueOf(
						personas * dias * alojamiento.getPrecio() + personas * dias * alojamiento.getPrecio() * 0.1)
						+ "�");
				alojamiento.setDesayuno(true);
			} else {
				getLblPrecio().setText(String.valueOf(personas * dias * alojamiento.getPrecio()) + "�");
				alojamiento.setDesayuno(false);
			}
		} else {
			getLblPrecio().setText(String.valueOf(dias * alojamiento.getPrecio()) + "�");
		}

	}

	private JLabel getLblNombre() {
		if (lblNombre == null) {
			lblNombre = new JLabel(alojamiento.getNombre());
		}
		return lblNombre;
	}

	private JLabel getLblPrecio() {
		if (lblPrecio == null) {
			lblPrecio = new JLabel();
		}
		return lblPrecio;
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Total:");
		}
		return lblNewLabel;
	}

	private JPanel getPanel_observaciones() {
		if (panel_observaciones == null) {
			panel_observaciones = new JPanel();
			panel_observaciones.setBackground(Color.WHITE);
			panel_observaciones.setBorder(new TitledBorder(null, "Observaciones:", TitledBorder.LEADING,
					TitledBorder.TOP, null, Color.BLACK));
			panel_observaciones.setLayout(new BorderLayout(0, 0));
			panel_observaciones.add(getScrollPane());
		}
		return panel_observaciones;
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getTextArea());
		}
		return scrollPane;
	}

	private JTextArea getTextArea() {
		if (textArea == null) {
			textArea = new JTextArea();
			textArea.setToolTipText("Escribe los comentarios que quieras dejar en tu reserva");
			textArea.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					alojamiento.setObservaciones(getTextArea().getText());
				}
			});
			textArea.setLineWrap(true);

		}
		return textArea;
	}

	private JCheckBox getDesayuno() {
		if (desayuno == null) {
			desayuno = new JCheckBox();
			desayuno.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					calcularPrecio((int) spinner.getValue(), alojamiento.getDuracion());

				}
			});

		}
		return desayuno;
	}

	private JPanel getPanel_desayuno() {
		if (panel_desayuno == null) {
			panel_desayuno = new JPanel();
			panel_desayuno.setBackground(Color.WHITE);
			if (alojamiento.getTipo() == "HO") {
				panel_desayuno.add(new JLabel("Desayuno: "));
				panel_desayuno.add(getDesayuno());
				getDesayuno().setVisible(true);
			}
		}
		return panel_desayuno;
	}

	
}
