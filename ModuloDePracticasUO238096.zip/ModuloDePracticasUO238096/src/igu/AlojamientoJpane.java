package igu;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.border.EmptyBorder;

import java.util.Date;
import logica.Alojamiento;
import logica.Reserva;

import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.border.SoftBevelBorder;

import javax.swing.border.BevelBorder;
import java.awt.Color;

import javax.swing.SwingConstants;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;

public class AlojamientoJpane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel paquetePictLbl;
	private JPanel detailsPane;
	private JPanel DenominacionPane;
	private JLabel DenominacionLbl;
	private String imgPath;
	// private Paquete paquete;
	private JPanel PrecioPane;
	private JLabel precio;
	// private Agencia agencia;
	private JButton btnReservar;
	private Alojamiento alojamiento;
	@SuppressWarnings("unused")
	private String denominacion;
	private JLabel lbPrecio;
	private Carrito carrito;
	private JPanel panel_categoria;
	private JLabel lblCategoria;
	private JPanel panel_fecha;
	private JDateChooser dateChooser_llegada;
	private JDateChooser dateChooser_salida;

	final long MILLSECS_PER_DAY = 24 * 60 * 60 * 1000;

	/**
	 * Create the panel.
	 */
	public AlojamientoJpane(Alojamiento alojamiento, Carrito carrito) {
		setBackground(new Color(255, 255, 255));
		// this.agencia = agencia;
		this.alojamiento = alojamiento;
		this.carrito = carrito;
		imgPath = "/img/" + this.alojamiento.getCodigo() + ".jpg";
		denominacion = this.alojamiento.getDenominacion();

		setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.DARK_GRAY, null, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		add(getPaquetePictLbl());
		add(getDetailsPane());
		add(getPanel_fecha());

	}

	private JLabel getPaquetePictLbl() {
		if (paquetePictLbl == null) {
			paquetePictLbl = new JLabel("");
			paquetePictLbl.setHorizontalAlignment(SwingConstants.LEFT);
			paquetePictLbl.setBorder(null);
			paquetePictLbl.setBackground(new Color(255, 255, 255));
			ImageIcon icon = new ImageIcon(VentanaPrincipal.class.getResource(imgPath));
			Image img = icon.getImage();
			Image redimImg = img.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
			ImageIcon redimIcon = new ImageIcon(redimImg);

			paquetePictLbl.setIcon(redimIcon);
			paquetePictLbl.setVerticalAlignment(JLabel.CENTER);
		}
		return paquetePictLbl;
	}

	private JPanel getDetailsPane() {
		if (detailsPane == null) {
			detailsPane = new JPanel();
			detailsPane.setBackground(new Color(255, 255, 255));
			detailsPane.setBorder(new EmptyBorder(0, 0, 0, 0));
			detailsPane.setLayout(new GridLayout(5, 5, 0, 0));
			detailsPane.add(getDenominacionPane());
			detailsPane.add(getPanel_categoria());
			detailsPane.add(getPrecioPane());
			detailsPane.add(getBtnReservar());

		}
		return detailsPane;
	}

	private JPanel getDenominacionPane() {
		if (DenominacionPane == null) {
			DenominacionPane = new JPanel();
			DenominacionPane.setBackground(new Color(255, 255, 255));
			DenominacionPane.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));
			DenominacionPane.add(getDenominacionLbl());
		}
		return DenominacionPane;
	}

	private JLabel getDenominacionLbl() {
		if (DenominacionLbl == null) {
			DenominacionLbl = new JLabel(alojamiento.getDenominacion());
			DenominacionLbl.setHorizontalAlignment(SwingConstants.RIGHT);
			DenominacionLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return DenominacionLbl;
	}

	private JPanel getPrecioPane() {
		if (PrecioPane == null) {
			PrecioPane = new JPanel();
			PrecioPane.setBackground(new Color(255, 255, 255));
			PrecioPane.add(getPrecio());
			PrecioPane.add(getLbPrecio());
		}
		return PrecioPane;
	}

	private JLabel getPrecio() {
		if (precio == null) {
			if (alojamiento.getTipo().equals("HO"))
				precio = new JLabel("Precio: " + alojamiento.getPrecio() + "\u20AC persona/noche");
			else
				precio = new JLabel("Precio: " + alojamiento.getPrecio() + "\u20AC total/noche");
			precio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return precio;
	}

	private String calculoFechaInicio() {
		if (checkDate() == true) {
			Date fecha = getDateChooser_llegada().getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			String f = sdf.format(fecha);
			return f;
		}
		return null;
	}

	private void reservaAlojamiento() {
		Reserva ra = new Reserva(alojamiento.getCodigo(), alojamiento.getPlazas(), alojamiento.getPrecio(),
				calculoFechaInicio(), calularduracion(), alojamiento.getDenominacion(), alojamiento.getTipo(), -1, -1,
				-1, -1, null, false);
		ReservaVentana rVentana = new ReservaVentana(new ReservaAlojamientoJpane(ra, carrito), carrito, ra);
		rVentana.setLocationRelativeTo(null);
		rVentana.setVisible(true);
	}

	private int calularduracion() {

		Date salida = (getDateChooser_salida().getDate());
		Date llegada = (getDateChooser_llegada().getDate());
		long diferencia = (salida.getTime() - llegada.getTime()) / MILLSECS_PER_DAY;
		return (int) diferencia;

	}

	private JButton getBtnReservar() {
		if (btnReservar == null) {
			btnReservar = new JButton("Reservar");
			btnReservar.setToolTipText("Realiza la reserva");
			btnReservar.setMnemonic('R');
			btnReservar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (checkDate() == true)
						reservaAlojamiento();
					else
						JOptionPane.showMessageDialog(null, "Seleccione una fecha de entrada y de salida v�lidas",
								"Atenci�n", JOptionPane.WARNING_MESSAGE);
				}
			});
			btnReservar.setBackground(Color.LIGHT_GRAY);
		}
		return btnReservar;
	}

	private JLabel getLbPrecio() {
		if (lbPrecio == null) {
			lbPrecio = getPrecio();
		}
		return lbPrecio;
	}

	private JPanel getPanel_categoria() {
		if (panel_categoria == null) {
			panel_categoria = new JPanel();
			panel_categoria.setBackground(Color.WHITE);
			panel_categoria.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));
			panel_categoria.add(getLblCategoria());
		}
		return panel_categoria;
	}

	private JLabel getLblCategoria() {
		if (lblCategoria == null) {
			lblCategoria = new JLabel("Categoria: " + alojamiento.getCategoria());
			lblCategoria.setHorizontalAlignment(SwingConstants.RIGHT);
			lblCategoria.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return lblCategoria;
	}

	private JPanel getPanel_fecha() {
		if (panel_fecha == null) {
			panel_fecha = new JPanel();
			panel_fecha.setBackground(Color.WHITE);
			panel_fecha.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"),
					"     Fecha Llegada ------ Fecha Salida", TitledBorder.LEADING, TitledBorder.TOP, null,
					new Color(0, 0, 0)));
			panel_fecha.add(getDateChooser_llegada());
			panel_fecha.add(getDateChooser_salida());
		}
		return panel_fecha;
	}

	private JDateChooser getDateChooser_llegada() {
		if (dateChooser_llegada == null) {
			dateChooser_llegada = new JDateChooser();
			dateChooser_llegada.setToolTipText("Selecciona la fecha de llegada");
			dateChooser_llegada.setLocale(getDefaultLocale());
			dateChooser_llegada.setDateFormatString("dd-MM-yyyy");

		}
		return dateChooser_llegada;
	}

	private JDateChooser getDateChooser_salida() {
		if (dateChooser_salida == null) {
			dateChooser_salida = new JDateChooser();
			dateChooser_salida.setToolTipText("Selecciona la fecha de salida");
			dateChooser_salida.setLocale(getDefaultLocale());
			dateChooser_salida.setDateFormatString("dd-MM-yyyy");
		}
		return dateChooser_salida;
	}

	private boolean checkDate() {
		String s = ((JTextField) getDateChooser_salida().getDateEditor().getUiComponent()).getText();
		String ll = ((JTextField) getDateChooser_llegada().getDateEditor().getUiComponent()).getText();

		if (s.equals("") || ll.equals("")
				|| getDateChooser_salida().getDate().before(getDateChooser_llegada().getDate())
				|| calularduracion() == 0)
			return false;
		return true;

	}

}
