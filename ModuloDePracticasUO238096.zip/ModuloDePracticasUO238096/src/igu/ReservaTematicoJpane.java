package igu;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.border.SoftBevelBorder;
import logica.Reserva;

import javax.swing.border.BevelBorder;
import java.awt.Color;

import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class ReservaTematicoJpane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Reserva entrada;
	private JPanel panel;
	private JPanel panel_nombre;
	private JPanel panel_precio;
	private JPanel panel_adultos;
	private JLabel lblNmeroDePersonas;
	private JSpinner spinner_adultos;
	private JLabel lblNombre;
	private JLabel lblPrecio;
	private JLabel lblNewLabel;
	@SuppressWarnings("unused")
	private Carrito carrito;
	private JPanel panel_ni�os;
	private JLabel lblNmeroDeNios;
	private JSpinner spinner_ni�os;

	/**
	 * Create the panel.
	 */
	public ReservaTematicoJpane(Reserva entrada, Carrito carrito) {
		this.entrada = entrada;
		this.carrito = carrito;
		setBackground(new Color(255, 255, 255));
		setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.DARK_GRAY, null, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		add(getPanel());
		entrada.setNi�os((int) spinner_ni�os.getValue());
		entrada.setAdultos((int) spinner_adultos.getValue());

	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBorder(new EmptyBorder(0, 0, 0, 0));
			panel.setBackground(Color.WHITE);
			panel.setLayout(new GridLayout(0, 1, 2, 2));
			panel.add(getPanel_nombre());
			panel.add(getPanel_adultos());
			panel.add(getPanel_ni�os());
			panel.add(getPanel_precio());

		}
		return panel;
	}

	private JPanel getPanel_nombre() {
		if (panel_nombre == null) {
			panel_nombre = new JPanel();
			panel_nombre.setBackground(Color.WHITE);
			panel_nombre.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));

			panel_nombre.add(getLblNombre());
		}
		return panel_nombre;
	}

	private JSpinner getSpinner_adultos() {
		if (spinner_adultos == null) {
			spinner_adultos = new JSpinner();
			spinner_adultos.setToolTipText("selecciona el numero de adultos");
			spinner_adultos.setModel(new SpinnerNumberModel(1, 1, 50, 1));
			spinner_adultos.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue());
					entrada.setAdultos((int) spinner_adultos.getValue());
				}
			});
			spinner_adultos.setForeground(Color.WHITE);
		}
		return spinner_adultos;
	}

	private JPanel getPanel_precio() {
		if (panel_precio == null) {
			panel_precio = new JPanel();
			panel_precio.setForeground(Color.BLACK);
			panel_precio.setBackground(Color.WHITE);
			panel_precio.add(getLblNewLabel());

			panel_precio.add(getLblPrecio());
		}
		return panel_precio;
	}

	private JPanel getPanel_adultos() {
		if (panel_adultos == null) {
			panel_adultos = new JPanel();
			panel_adultos.setBackground(Color.WHITE);
			panel_adultos.add(getLblNmeroDePersonas());
			panel_adultos.add(getSpinner_adultos());
		}
		return panel_adultos;
	}

	private JLabel getLblNmeroDePersonas() {
		if (lblNmeroDePersonas == null) {
			lblNmeroDePersonas = new JLabel("N\u00FAmero de adultos");
			lblNmeroDePersonas.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return lblNmeroDePersonas;
	}

	public void calcularPrecio(int adultos, int ni�os) {

		getLblPrecio()
				.setText(String.valueOf(adultos * entrada.getPrecioAdulto() + ni�os * entrada.getPrecioNi�o()) + "�");

	}

	private JLabel getLblNombre() {
		if (lblNombre == null) {
			lblNombre = new JLabel(entrada.getNombre());
		}
		return lblNombre;
	}

	private JLabel getLblPrecio() {
		if (lblPrecio == null) {
			lblPrecio = new JLabel();
			calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue());
		}
		return lblPrecio;
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Total:");
		}
		return lblNewLabel;
	}

	private JPanel getPanel_ni�os() {
		if (panel_ni�os == null) {
			panel_ni�os = new JPanel();
			panel_ni�os.setBackground(Color.WHITE);
			panel_ni�os.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			panel_ni�os.add(getLblNmeroDeNios());
			panel_ni�os.add(getSpinner_ni�os());
		}
		return panel_ni�os;
	}

	private JLabel getLblNmeroDeNios() {
		if (lblNmeroDeNios == null) {
			lblNmeroDeNios = new JLabel("N\u00FAmero de ni\u00F1os");
			lblNmeroDeNios.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return lblNmeroDeNios;
	}

	private JSpinner getSpinner_ni�os() {
		if (spinner_ni�os == null) {
			spinner_ni�os = new JSpinner();
			spinner_ni�os.setToolTipText("selecciona el numero de ni\u00F1os");
			spinner_ni�os.setModel(new SpinnerNumberModel(0, 0, 50, 1));
			spinner_ni�os.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue());
					entrada.setNi�os((int) spinner_ni�os.getValue());
				}
			});
			spinner_ni�os.setForeground(Color.WHITE);
		}
		return spinner_ni�os;
	}

}
