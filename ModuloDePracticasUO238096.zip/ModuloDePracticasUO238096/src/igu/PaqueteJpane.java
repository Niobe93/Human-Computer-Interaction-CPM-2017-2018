package igu;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.border.EmptyBorder;

import logica.Agencia;
import logica.Paquete;
import logica.Reserva;

import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.border.SoftBevelBorder;

import javax.swing.border.BevelBorder;
import java.awt.Color;

import javax.swing.SwingConstants;

import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import com.toedter.calendar.JDateChooser;

import java.util.Date;
import java.util.Locale;

public class PaqueteJpane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel paquetePictLbl;
	private JPanel detailsPane;
	private JPanel DenominacionPane;
	private JLabel DenominacionLbl;
	private JPanel AdultoPrecioPane;
	private JLabel AdultoPrecioLbl;
	private String imgPath;
	@SuppressWarnings("unused")
	private String denominacion;
	@SuppressWarnings("unused")
	private int duracion;
	private Paquete paquete;
	private JPanel NinoPrecioPane;
	private JLabel ninoPrecio;
	private JPanel DuracionPane;
	private JLabel duracionLbl;
	private JButton btnSaberMs;
	private Agencia agencia;
	private JButton btnReservar;
	private JPanel panel;
	private Carrito carrito;
	private JPanel panel_1;
	private JDateChooser dateChooser_llegada;
	@SuppressWarnings("unused")
	private JPanel panel_desayuno;
	@SuppressWarnings("unused")
	private JCheckBox desayuno;

	/**
	 * Create the panel.
	 */
	public PaqueteJpane(Agencia agencia, Paquete paquete, Carrito carrito) {
		setBackground(new Color(255, 255, 255));
		this.paquete = paquete;
		this.carrito = carrito;
		this.agencia = agencia;
		imgPath = "/img/" + this.paquete.getCodigo() + ".jpg";
		denominacion = this.paquete.getDenominacion();
		duracion = this.paquete.getDuracion();
		setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.DARK_GRAY, null, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		add(getPaquetePictLbl());
		add(getDetailsPane());
		add(getPanel_1());
		add(getPanel());

	}

	private JLabel getPaquetePictLbl() {
		if (paquetePictLbl == null) {
			paquetePictLbl = new JLabel("");
			paquetePictLbl.setHorizontalAlignment(SwingConstants.TRAILING);
			paquetePictLbl.setBorder(null);
			paquetePictLbl.setBackground(new Color(255, 255, 255));
			ImageIcon icon = new ImageIcon(VentanaPrincipal.class.getResource(imgPath));
			Image img = icon.getImage();
			Image redimImg = img.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
			ImageIcon redimIcon = new ImageIcon(redimImg);

			paquetePictLbl.setIcon(redimIcon);
			paquetePictLbl.setVerticalAlignment(JLabel.CENTER);
		}
		return paquetePictLbl;
	}

	private JPanel getDetailsPane() {
		if (detailsPane == null) {
			detailsPane = new JPanel();
			detailsPane.setBackground(new Color(255, 255, 255));
			detailsPane.setBorder(new EmptyBorder(0, 0, 0, 0));
			detailsPane.setLayout(new GridLayout(0, 1, 2, 2));
			detailsPane.add(getDenominacionPane());
			detailsPane.add(getPrecioAdultoPane());
			detailsPane.add(getNinoPrecioPane());
			detailsPane.add(getDuracionPane());

		}
		return detailsPane;
	}

	private JPanel getDenominacionPane() {
		if (DenominacionPane == null) {
			DenominacionPane = new JPanel();
			DenominacionPane.setBackground(new Color(255, 255, 255));
			DenominacionPane.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));
			DenominacionPane.add(getDenominacionLbl());
		}
		return DenominacionPane;
	}

	private JLabel getDenominacionLbl() {
		if (DenominacionLbl == null) {
			DenominacionLbl = new JLabel(paquete.getDenominacion());
			DenominacionLbl.setHorizontalAlignment(SwingConstants.LEFT);
			DenominacionLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return DenominacionLbl;
	}

	private JPanel getPrecioAdultoPane() {
		if (AdultoPrecioPane == null) {
			AdultoPrecioPane = new JPanel();
			AdultoPrecioPane.setForeground(new Color(0, 0, 0));
			AdultoPrecioPane.setBackground(new Color(255, 255, 255));
			AdultoPrecioPane.add(getPrecioAdultoLbl());
		}
		return AdultoPrecioPane;
	}

	private JLabel getPrecioAdultoLbl() {
		if (AdultoPrecioLbl == null) {
			AdultoPrecioLbl = new JLabel("Adultos completo: " + paquete.getPrecio_adulto() + " �");
			AdultoPrecioLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return AdultoPrecioLbl;
	}

	private JPanel getNinoPrecioPane() {
		if (NinoPrecioPane == null) {
			NinoPrecioPane = new JPanel();
			NinoPrecioPane.setBackground(new Color(255, 255, 255));
			NinoPrecioPane.add(getNinoPrecio());
		}
		return NinoPrecioPane;
	}

	private JLabel getNinoPrecio() {
		if (ninoPrecio == null) {
			ninoPrecio = new JLabel("Ni\u00F1os completo: " + paquete.getPrecio_ni�o() + " �");
			ninoPrecio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return ninoPrecio;
	}

	private JPanel getDuracionPane() {
		if (DuracionPane == null) {
			DuracionPane = new JPanel();
			DuracionPane.setBackground(new Color(255, 255, 255));
			DuracionPane.add(getDuracionLbl());
		}
		return DuracionPane;
	}

	private JLabel getDuracionLbl() {
		if (duracionLbl == null) {
			duracionLbl = new JLabel(paquete.getDuracion() + " d�as");
			duracionLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return duracionLbl;
	}

	private JButton getBtnSaberMs() {
		if (btnSaberMs == null) {
			btnSaberMs = new JButton("Info alojamiento");
			btnSaberMs.setToolTipText("Ver m\u00E1s informaci\u00F3n sobre el alojamiento");
			btnSaberMs.setMnemonic('I');
			btnSaberMs.setBackground(Color.LIGHT_GRAY);
			btnSaberMs.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					saberMasVentana();
				}
			});
		}
		return btnSaberMs;
	}

	private void saberMasVentana() {
		SaberMasVentana saberMasVentana = new SaberMasVentana(paquete.getCodigo_alojamiento(), agencia, paquete,
				carrito);
		saberMasVentana.setLocationRelativeTo(null);
		saberMasVentana.setVisible(true);
	}

	private JButton getBtnReservar() {
		if (btnReservar == null) {
			btnReservar = new JButton("Reservar");
			btnReservar.setToolTipText("Realiza la reserva");
			btnReservar.setMnemonic('R');
			btnReservar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (checkDate() == true)
						reservaPaquete();
					else
						JOptionPane.showMessageDialog(null, "Seleccione una fecha de entrada y de salida v�lidas",
								"Atenci�n", JOptionPane.WARNING_MESSAGE);
				}
			});
			btnReservar.setBackground(Color.LIGHT_GRAY);
		}
		return btnReservar;
	}

	private void reservaPaquete() {
		Reserva ra = new Reserva(paquete.getCodigo(),
				(agencia.searchAlojamiento(paquete.getCodigo_alojamiento()).getPlazas()), -1, calculoFechaInicio(),
				paquete.getDuracion(), paquete.getDenominacion(), "Paquete", paquete.getPrecio_adulto(),
				paquete.getPrecio_ni�o(), 0, 0, null, false);

		ReservaVentana rVentana = new ReservaVentana(new ReservaPaqueteJpane(agencia, ra, carrito), carrito, ra);
		rVentana.setLocationRelativeTo(null);
		rVentana.setVisible(true);
	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(Color.WHITE);
			panel.setLayout(new GridLayout(0, 1, 0, 0));
			panel.add(getBtnSaberMs());
			panel.add(getBtnReservar());
		}
		return panel;
	}

	private JPanel getPanel_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Fecha Inicio",
					TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_1.setBackground(Color.WHITE);
			panel_1.add(getDateChooser_llegada());
		}
		return panel_1;
	}

	private JDateChooser getDateChooser_llegada() {
		if (dateChooser_llegada == null) {
			dateChooser_llegada = new JDateChooser();
			dateChooser_llegada.setToolTipText("Selecciona la fecha de inicio");
			dateChooser_llegada.setLocale(new Locale("es", "ES"));
			dateChooser_llegada.setDateFormatString("dd-MM-yyyy");
		}
		return dateChooser_llegada;
	}

	private String calculoFechaInicio() {
		Date fecha = getDateChooser_llegada().getDate();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String f = sdf.format(fecha);
		return f;
	}

	private boolean checkDate() {
		String ll = ((JTextField) getDateChooser_llegada().getDateEditor().getUiComponent()).getText();

		if (ll.equals(""))
			return false;
		return true;

	}

}
