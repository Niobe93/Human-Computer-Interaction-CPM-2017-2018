package igu;

import javax.swing.JDialog;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import javax.swing.JTextField;

import logica.Agencia;
import logica.Reserva;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FacturaVentana extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textFieldNombre;
	private JTextField textField;
	@SuppressWarnings("unused")
	private Agencia agencia;
	@SuppressWarnings("unused")
	private ArrayList<Reserva> reservados;
	@SuppressWarnings("unused")
	private Carrito carrito;

	/**
	 * Create the dialog.
	 */
	public FacturaVentana(Agencia agencia, ArrayList<Reserva> reservados, Carrito carrito) {
		this.agencia = agencia;
		this.carrito = carrito;
		setIconImage(Toolkit.getDefaultToolkit().getImage(FacturaVentana.class.getResource("/img/logo.jpg")));
		setTitle("Registro de cliente");
		setModal(true);
		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 515, 353);
		getContentPane().setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(2, 0, 0, 0));

		JPanel panel_nombre = new JPanel();
		panel_nombre.setBackground(Color.WHITE);
		panel.add(panel_nombre);

		JLabel lblNewLabel = new JLabel("Nombre y apellidos:");
		lblNewLabel.setToolTipText("Introduce tu nombre y tus apellidos ");
		lblNewLabel.setDisplayedMnemonic('N');
		panel_nombre.add(lblNewLabel);

		textFieldNombre = new JTextField();
		panel_nombre.add(textFieldNombre);
		textFieldNombre.setColumns(10);

		JPanel panel_DNI = new JPanel();
		panel_DNI.setBackground(Color.WHITE);
		panel.add(panel_DNI);

		JLabel lblDninif = new JLabel("DNI/NIF:");
		lblDninif.setToolTipText("Introduce tu DNI/NIF con el formato 11111111-X");
		lblDninif.setDisplayedMnemonic('D');
		panel_DNI.add(lblDninif);

		textField = new JTextField();
		textField.setColumns(10);
		panel_DNI.add(textField);

		JPanel panel_botones = new JPanel();
		panel_botones.setBackground(Color.LIGHT_GRAY);
		getContentPane().add(panel_botones, BorderLayout.SOUTH);

		JButton btnContinuar = new JButton("Continuar");
		btnContinuar.setMnemonic('P');
		btnContinuar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (controlarTextos() == false)
					JOptionPane.showMessageDialog(null, "Por favor, rellene correctamente todos los campos");

				else {
					int option = JOptionPane.showConfirmDialog(null, "�Seguro que desea confirmar su reserva?",
							"Confirmar reserva", JOptionPane.WARNING_MESSAGE);
					if (option == 0) {
						JOptionPane.showMessageDialog(null,
								"Compra realizada con �xito. Gracias por confiar en nosotros. Felices Vacaciones de parte del equipo de Logo.es.");
						agencia.generarFactura(textFieldNombre.getText(), textField.getText(), reservados);
						mostrarVentanaJustificante(agencia, carrito, reservados, textFieldNombre.getText(),
								textField.getText());

						carrito.inicializar();
						dispose();
					} else
						dispose();

				}
			}
		});

		panel_botones.add(btnContinuar);

		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setMnemonic('C');
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		panel_botones.add(btnCancelar);

	}

	private void mostrarVentanaJustificante(Agencia agencia, Carrito carrito, ArrayList<Reserva> reservados,
			String nombre, String dni) {
		Justificante j = new Justificante(agencia, carrito, reservados, nombre, dni);
		j.setLocationRelativeTo(this);
		j.setVisible(true);

	}

	private boolean controlarTextos() {
		if ((textField.getText().trim().isEmpty()) || (textFieldNombre.getText().trim().isEmpty()))
			return false;
		return true;
	}

}
