package igu;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Reserva;

import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JScrollPane;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class ReservaVentana extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JPanel panel_reservas;
	private JPanel a�adir;
	private JPanel panel_1;
	private JButton button_a�adir;
	private Carrito carrito;
	private Reserva reserva;
	private JButton btnCerrar;
	private JPanel panel_2;
	private JPanel panel_3;

	/**
	 * Create the frame.
	 * 
	 * @param paquete
	 * @param agencia
	 */
	public ReservaVentana(JPanel panel, Carrito carrito, Reserva reserva) {
		this.carrito = carrito;
		this.reserva = reserva;
		this.a�adir = panel;
		setTitle("Tu reserva");
		setIconImage(Toolkit.getDefaultToolkit().getImage(ReservaVentana.class.getResource("/img/logo.jpg")));
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 584, 458);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.add(getScrollPane(), BorderLayout.CENTER);
		contentPane.add(getPanel_1(), BorderLayout.SOUTH);

	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getPanel_reservas());
		}
		return scrollPane;
	}

	private JPanel getPanel_reservas() {
		if (panel_reservas == null) {
			panel_reservas = new JPanel();
			panel_reservas.setBackground(Color.WHITE);
			panel_reservas.setLayout(new GridLayout(1, 0, 0, 0));
			panel_reservas.add(a�adir);
		}
		return panel_reservas;
	}

	private JPanel getPanel_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBackground(Color.WHITE);
			panel_1.setLayout(new BorderLayout(0, 0));
			panel_1.add(getPanel_3(), BorderLayout.EAST);
			panel_1.add(getPanel_2(), BorderLayout.WEST);
		}
		return panel_1;
	}

	private JButton getButton_a�adir() {
		if (button_a�adir == null) {
			button_a�adir = new JButton("A\u00F1adir reserva");
			button_a�adir.setToolTipText("A\u00F1ade al carrito la reserva ");
			button_a�adir.setMnemonic('A');
			button_a�adir.setBackground(Color.LIGHT_GRAY);
			button_a�adir.setHorizontalAlignment(SwingConstants.RIGHT);
			button_a�adir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					carrito.a�adirCarrito(reserva, a�adir);
					dispose();
				}
			});
		}
		return button_a�adir;
	}

	private JButton getBtnCerrar() {
		if (btnCerrar == null) {
			btnCerrar = new JButton("Cancelar");
			btnCerrar.setToolTipText("Cancela la reserva");
			btnCerrar.setMnemonic('C');
			btnCerrar.setBackground(Color.LIGHT_GRAY);
			btnCerrar.setHorizontalAlignment(SwingConstants.RIGHT);
			btnCerrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
		}
		return btnCerrar;
	}

	private JPanel getPanel_2() {
		if (panel_2 == null) {
			panel_2 = new JPanel();
			panel_2.setBackground(Color.WHITE);
			panel_2.add(getButton_a�adir());
		}
		return panel_2;
	}

	private JPanel getPanel_3() {
		if (panel_3 == null) {
			panel_3 = new JPanel();
			panel_3.setBackground(Color.WHITE);
			panel_3.add(getBtnCerrar());
		}
		return panel_3;
	}
}
