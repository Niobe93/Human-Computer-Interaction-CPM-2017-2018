package igu;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Agencia;
import logica.Alojamiento;
import logica.Paquete;
import logica.Reserva;
import logica.Tematico;

import javax.swing.JLabel;
import java.awt.Image;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.GridLayout;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SaberMasVentana extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private String codigoAlojamiento;
	private JLabel lblimagen;
	private String imgPath;
	private JPanel panel_detalles;
	private Agencia agencia;
	private JPanel panel_nombre;
	private JLabel lbldescripcion;
	private Alojamiento alojamiento;
	private Paquete paquete;
	private JPanel panel_parque;
	private JLabel label_precio;
	private JPanel panel_categoria;
	private JLabel label_categoria;
	private Tematico tematico;
	private JButton btnReservar;
	private JButton btnVerParque;
	private JButton btnNewButton;
	private Carrito carrito;

	/**
	 * Create the frame.
	 * 
	 * @param codigo
	 */
	public SaberMasVentana(String codigo, Agencia agencia, Paquete paquete, Carrito carrito) {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(SaberMasVentana.class.getResource("/img/logo.jpg")));
		setTitle("Informaci\u00F3n alojamiento");
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 238);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		this.codigoAlojamiento = codigo;
		this.carrito = carrito;
		this.paquete = paquete;
		this.agencia = agencia;
		this.tematico = agencia.searchParque(paquete.getCodigo_parque());
		alojamiento = agencia.searchAlojamiento(codigoAlojamiento);
		imgPath = "/img/" + this.codigoAlojamiento + ".jpg";
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		contentPane.add(getLblimagen());
		contentPane.add(getPanel_1());
		contentPane.add(getBtnReservar());
		contentPane.add(getBtnVerParque());
		contentPane.add(getBtnNewButton());
	}

	private JLabel getLblimagen() {
		if (lblimagen == null) {
			lblimagen = new JLabel("");
			lblimagen.setBackground(Color.WHITE);
			ImageIcon icon = new ImageIcon(VentanaPrincipal.class.getResource(imgPath));
			Image img = icon.getImage();
			Image redimImg = img.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
			ImageIcon redimIcon = new ImageIcon(redimImg);

			lblimagen.setIcon(redimIcon);
			lblimagen.setVerticalAlignment(JLabel.CENTER);
		}
		return lblimagen;
	}

	private JPanel getPanel_1() {
		if (panel_detalles == null) {
			panel_detalles = new JPanel();
			panel_detalles.setBackground(Color.WHITE);
			panel_detalles.setLayout(new GridLayout(0, 1, 0, 0));
			panel_detalles.add(getPanel_nombre());
			panel_detalles.add(getPanel_3());
			panel_detalles.add(getPanel_2());
		}
		return panel_detalles;
	}

	private JPanel getPanel_nombre() {
		if (panel_nombre == null) {
			panel_nombre = new JPanel();
			panel_nombre.setBackground(Color.WHITE);
			panel_nombre.add(getLbldescripcion());
		}
		return panel_nombre;
	}

	private JLabel getLbldescripcion() {
		if (lbldescripcion == null) {
			lbldescripcion = new JLabel(alojamiento.getDenominacion());
			lbldescripcion.setHorizontalAlignment(SwingConstants.CENTER);
			lbldescripcion.setBackground(Color.WHITE);
		}
		return lbldescripcion;
	}

	private JPanel getPanel_2() {
		if (panel_parque == null) {
			panel_parque = new JPanel();
			panel_parque.setBackground(Color.WHITE);
			panel_parque.setLayout(new GridLayout(0, 1, 0, 0));
			panel_parque.add(getLabel_precio());
		}
		return panel_parque;
	}

	private JLabel getLabel_precio() {
		if (label_precio == null) {
			label_precio = new JLabel(tematico.getDenominacion());
			label_precio.setHorizontalAlignment(SwingConstants.CENTER);
			label_precio.setBackground(Color.WHITE);
		}
		return label_precio;
	}

	private JPanel getPanel_3() {
		if (panel_categoria == null) {
			panel_categoria = new JPanel();
			panel_categoria.setBackground(Color.WHITE);
			panel_categoria.add(getLabel_categoria());
		}
		return panel_categoria;
	}

	private JLabel getLabel_categoria() {
		if (label_categoria == null) {
			label_categoria = new JLabel("Categor�a: " + alojamiento.getCategoria() + " estrellas");
			label_categoria.setHorizontalAlignment(SwingConstants.CENTER);
			label_categoria.setBackground(Color.WHITE);
		}
		return label_categoria;
	}

	private JButton getBtnReservar() {
		if (btnReservar == null) {
			btnReservar = new JButton("Reservar");
			btnReservar.setToolTipText("Realizar la reserva");
			btnReservar.setMnemonic('R');
			btnReservar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					reservaPaquete();
				}
			});
		}
		return btnReservar;
	}

	private void reservaPaquete() {
		Reserva ra = new Reserva(paquete.getCodigo(),
				(agencia.searchAlojamiento(paquete.getCodigo_alojamiento()).getPlazas()), -1, null,
				paquete.getDuracion(), paquete.getDenominacion(), null, paquete.getPrecio_adulto(),
				paquete.getPrecio_ni�o(), -1, -1, null, false);

		ReservaVentana rVentana = new ReservaVentana(new ReservaPaqueteJpane(agencia, ra, carrito), carrito, ra);
		rVentana.setLocationRelativeTo(null);
		rVentana.setVisible(true);
	}

	private JButton getBtnVerParque() {
		if (btnVerParque == null) {
			btnVerParque = new JButton("Ver Parque");
			btnVerParque.setToolTipText("Ver m\u00E1s informaci\u00F3n del parque");
			btnVerParque.setMnemonic('V');
			btnVerParque.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					saberMasParque();
				}
			});
		}
		return btnVerParque;
	}

	private void saberMasParque() {
		SaberMasParqueVentana smpv = new SaberMasParqueVentana(agencia, paquete);
		smpv.setLocationRelativeTo(null);
		smpv.setVisible(true);
	}

	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("Cerrar");
			btnNewButton.setToolTipText("Cerrar la ventana");
			btnNewButton.setMnemonic('C');
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
		}
		return btnNewButton;
	}
}
