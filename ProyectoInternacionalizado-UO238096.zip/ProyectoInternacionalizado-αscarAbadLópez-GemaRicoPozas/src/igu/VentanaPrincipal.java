package igu;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.text.DateFormat;
import java.util.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel pnBotones;
	private JPanel pnFechaHora;
	private JPanel pnBandera;
	private JPanel pnTexto;
	private JButton btEspa�ol;
	private JButton btIngles;
	private JButton btFrances;
	private JLabel lbFecha;
	private JLabel lbHora;
	private JLabel lbBandera;
	private JTextArea taTexto;
	private Locale localizacion;
	private JButton btnIta;
	private JTextField textBandera;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {

		setTitle("Ejemplo de Internacionalizaci�n");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.add(getPnBotones(), BorderLayout.NORTH);
		contentPane.add(getPnFechaHora(), BorderLayout.SOUTH);
		contentPane.add(getPnBandera(), BorderLayout.WEST);
		contentPane.add(getPnTexto(), BorderLayout.CENTER);
		localizacion = Locale.getDefault(Locale.Category.FORMAT);
		localizar(localizacion);

	}

	private JPanel getPnBotones() {
		if (pnBotones == null) {
			pnBotones = new JPanel();
			pnBotones.add(getBtEspa�ol());
			pnBotones.add(getBtIngles());
			pnBotones.add(getBtFrances());
			pnBotones.add(getBtnIta());
		}
		return pnBotones;
	}

	private JPanel getPnFechaHora() {
		if (pnFechaHora == null) {
			pnFechaHora = new JPanel();
			pnFechaHora.setLayout(new GridLayout(1, 2, 0, 0));
			pnFechaHora.add(getLbFecha());
			pnFechaHora.add(getLbHora());
		}
		return pnFechaHora;
	}

	private JPanel getPnBandera() {
		if (pnBandera == null) {
			pnBandera = new JPanel();
			pnBandera.setLayout(new GridLayout(0, 1, 0, 3));
			pnBandera.add(getLbBandera());
			pnBandera.add(getTextBandera());
		}
		return pnBandera;
	}

	private JPanel getPnTexto() {
		if (pnTexto == null) {
			pnTexto = new JPanel();
			pnTexto.setLayout(new BorderLayout(0, 0));
			pnTexto.add(getTaTexto(), BorderLayout.CENTER);
		}
		return pnTexto;
	}

	private JButton getBtEspa�ol() {
		if (btEspa�ol == null) {
			btEspa�ol = new JButton("ES");
			btEspa�ol.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {

					localizar(new Locale("es_ES", "Espa�a"));
				}
			});
		}
		return btEspa�ol;
	}

	private JButton getBtIngles() {
		if (btIngles == null) {
			btIngles = new JButton("EN");
			btIngles.setToolTipText("");
			btIngles.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					localizar(new Locale("en_EN", "England"));
				}
			});
		}
		return btIngles;
	}

	private JButton getBtFrances() {
		if (btFrances == null) {
			btFrances = new JButton("FR");
			btFrances.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					localizar(new Locale("fr_FR", "France"));

				}
			});
		}
		return btFrances;
	}

	private JButton getBtnIta() {
		if (btnIta == null) {
			btnIta = new JButton("ITA");
			btnIta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					localizar(new Locale("it_IT", "Italia"));
				}
			});
		}
		return btnIta;
	}

	private JLabel getLbFecha() {
		if (lbFecha == null) {
			lbFecha = new JLabel("");
		}
		return lbFecha;
	}

	private JLabel getLbHora() {
		if (lbHora == null) {
			lbHora = new JLabel("");
		}
		return lbHora;
	}

	private JLabel getLbBandera() {
		if (lbBandera == null) {
			lbBandera = new JLabel("");

		}
		return lbBandera;
	}

	private JTextArea getTaTexto() {
		if (taTexto == null) {
			taTexto = new JTextArea();
			taTexto.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 20));
			taTexto.setWrapStyleWord(true);
			taTexto.setLineWrap(true);
		}
		return taTexto;
	}

	private JTextField getTextBandera() {
		if (textBandera == null) {
			textBandera = new JTextField();
			textBandera.setHorizontalAlignment(SwingConstants.CENTER);
			textBandera.setFont(new Font("Tahoma", Font.PLAIN, 11));
			textBandera.setFocusable(false);
			textBandera.setEditable(false);
			textBandera.setBackground(UIManager.getColor("CheckBoxMenuItem.background"));
			textBandera.setColumns(2);

		}
		return textBandera;
	}
	

	private void localizar(Locale localizacion) {

		ResourceBundle textos = ResourceBundle.getBundle("rcs/textos", localizacion);
		this.getTaTexto().setText((textos.getString("texto1")));
		this.getBtEspa�ol().setToolTipText(textos.getString("texto2"));
		this.getBtFrances().setToolTipText(textos.getString("texto3"));
		this.getBtnIta().setToolTipText(textos.getString("texto4"));
		this.getBtIngles().setToolTipText(textos.getString("texto5"));

		String[] cadena = localizacion.toString().split("_");
		String imagenBandera = "/img/" + cadena[0] + ".PNG";

		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource(imagenBandera)));
		lbBandera.setIcon(new ImageIcon(VentanaPrincipal.class.getResource(imagenBandera)));

		textBandera.setText(localizacion.getDisplayCountry());
		setFechaHora(cadena[1]);

	}

	private void setFechaHora(String locale) {

		Date fechaHora = new Date();

		DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.FULL, new Locale(locale));
		String fecha = dateFormatter.format(fechaHora);
		lbFecha.setText(fecha);

		DateFormat formatoHora = DateFormat.getTimeInstance(DateFormat.FULL, new Locale(locale));
		String hora = formatoHora.format(fechaHora);
		lbHora.setText(hora);

	}

}
