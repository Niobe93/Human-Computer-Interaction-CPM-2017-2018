package igu;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.border.EmptyBorder;

import logica.Agencia;
import logica.Entrada;
import logica.Paquete;
import logica.Reserva;
import logica.Tematico;

import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.border.SoftBevelBorder;

import javax.swing.border.BevelBorder;
import java.awt.Color;

import javax.swing.SwingConstants;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import com.toedter.calendar.JDateChooser;

import java.util.Date;
import java.util.Locale;

public class TematicoJpane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel tematicoPictLbl;
	private JPanel detailsPane;
	private JPanel DenominacionPane;
	private JLabel DenominacionLbl;
	private String imgPath;
	private JPanel PrecioAdultoPane;
	private JLabel precio;
	private JButton btnReservar;
	private Entrada entrada;
	@SuppressWarnings("unused")
	private String denominacion;
	private Tematico tematico;
	private JPanel PrecioNinoPane;
	private JLabel precioNino;
	private Carrito carrito;
	private JPanel panel;
	private JDateChooser dateChooser_llegada;
	private JDateChooser dateChooser_salida;
	final long MILLSECS_PER_DAY = 24 * 60 * 60 * 1000;
	private JButton btnVermas;
	private Agencia agencia;

	/**
	 * Create the panel.
	 */
	public TematicoJpane(Tematico tematico, Agencia agencia, Carrito carrito) {
		setBackground(new Color(255, 255, 255));
		this.tematico = tematico;
		this.agencia = agencia;
		this.carrito = carrito;
		this.entrada = agencia.searchEntradaByParque(tematico.getCodigo());
		imgPath = "/img/" + this.tematico.getCodigo() + ".jpg";
		denominacion = this.tematico.getDenominacion();

		setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.DARK_GRAY, null, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		add(getTematicoPictLbl());
		add(getDetailsPane());
		add(getPanel());

	}

	private JLabel getTematicoPictLbl() {
		if (tematicoPictLbl == null) {
			tematicoPictLbl = new JLabel("");
			tematicoPictLbl.setHorizontalAlignment(SwingConstants.LEFT);
			tematicoPictLbl.setBorder(null);
			tematicoPictLbl.setBackground(new Color(255, 255, 255));
			ImageIcon icon = new ImageIcon(VentanaPrincipal.class.getResource(imgPath));
			Image img = icon.getImage();
			Image redimImg = img.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
			ImageIcon redimIcon = new ImageIcon(redimImg);

			tematicoPictLbl.setIcon(redimIcon);
			tematicoPictLbl.setVerticalAlignment(JLabel.CENTER);
		}
		return tematicoPictLbl;
	}

	private JPanel getDetailsPane() {
		if (detailsPane == null) {
			detailsPane = new JPanel();
			detailsPane.setBackground(new Color(255, 255, 255));
			detailsPane.setBorder(new EmptyBorder(0, 0, 0, 0));
			detailsPane.setLayout(new GridLayout(0, 1, 2, 2));
			detailsPane.add(getDenominacionPane());
			detailsPane.add(getPrecioAdultoPane());
			detailsPane.add(getPrecioNinoPane());
			detailsPane.add(getBtnVermas());
			detailsPane.add(getBtnReservar());

		}
		return detailsPane;
	}

	private JPanel getDenominacionPane() {
		if (DenominacionPane == null) {
			DenominacionPane = new JPanel();
			DenominacionPane.setBackground(new Color(255, 255, 255));
			DenominacionPane.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));
			DenominacionPane.add(getDenominacionLbl());
		}
		return DenominacionPane;
	}

	private JLabel getDenominacionLbl() {
		if (DenominacionLbl == null) {
			DenominacionLbl = new JLabel(tematico.getDenominacion());
			DenominacionLbl.setHorizontalAlignment(SwingConstants.RIGHT);
			DenominacionLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return DenominacionLbl;
	}

	private JPanel getPrecioAdultoPane() {
		if (PrecioAdultoPane == null) {
			PrecioAdultoPane = new JPanel();
			PrecioAdultoPane.setBackground(new Color(255, 255, 255));
			PrecioAdultoPane.add(getPrecio());
		}
		return PrecioAdultoPane;
	}

	private JLabel getPrecio() {
		if (precio == null) {
			precio = new JLabel("Precio: " + entrada.getPrecio_adulto() + "\u20AC por adulto");
			precio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return precio;
	}

	private JButton getBtnReservar() {
		if (btnReservar == null) {
			btnReservar = new JButton("Comprar Entradas");
			btnReservar.setToolTipText("Realizar la reserva de entradas");
			btnReservar.setMnemonic('C');
			btnReservar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (checkDate() == true) {
						if(tematico.isDisponible())
							reservaEntradas();
						else 
							JOptionPane.showMessageDialog(null, "Lo sentimos el parque tem�tico est� completo",
									"Atenci�n", JOptionPane.WARNING_MESSAGE);}
					else
						JOptionPane.showMessageDialog(null, "Seleccione una fecha de entrada y de salida v�lidas",
								"Atenci�n", JOptionPane.WARNING_MESSAGE);
				}
			});
			btnReservar.setBackground(Color.LIGHT_GRAY);
		}
		return btnReservar;
	}

	private JPanel getPrecioNinoPane() {
		if (PrecioNinoPane == null) {
			PrecioNinoPane = new JPanel();
			PrecioNinoPane.setBackground(Color.WHITE);
			PrecioNinoPane.add(getPrecioNino());
		}
		return PrecioNinoPane;
	}

	private JLabel getPrecioNino() {
		if (precioNino == null) {
			precioNino = new JLabel("Precio: " + entrada.getPrecio_ni�o() + "\u20AC por ni�o");
			precioNino.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return precioNino;
	}

	private void reservaEntradas() {
		Reserva ra = new Reserva(entrada.getCodigo(), -1, -1, calculoFechaInicio(), calularduracion(),
				tematico.getDenominacion(), "Entrada", entrada.getPrecio_adulto(), entrada.getPrecio_ni�o(), -1, -1,
				null, false, false);
		ReservaVentana rVentana = new ReservaVentana(new ReservaTematicoJpane(ra, carrito), carrito, ra);
		rVentana.setLocationRelativeTo(null);
		rVentana.setVisible(true);
	}

	private int calularduracion() {

		Date salida = (getDateChooser_salida().getDate());
		Date llegada = (getDateChooser_llegada().getDate());
		long diferencia = (salida.getTime() - llegada.getTime()) / MILLSECS_PER_DAY;
		return (int) diferencia;

	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBorder(
					new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Validez     Desde ------ Hasta",
							TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel.setBackground(Color.WHITE);
			panel.add(getDateChooser_llegada());
			panel.add(getDateChooser_salida());
		}
		return panel;
	}

	private JDateChooser getDateChooser_llegada() {
		if (dateChooser_llegada == null) {
			dateChooser_llegada = new JDateChooser();
			dateChooser_llegada.setToolTipText("Selecciona fecha de inicio");
			dateChooser_llegada.setLocale(new Locale("es", "ES"));
			dateChooser_llegada.setDateFormatString("dd-MM-yyyy");
		}
		return dateChooser_llegada;
	}

	private JDateChooser getDateChooser_salida() {
		if (dateChooser_salida == null) {
			dateChooser_salida = new JDateChooser();
			dateChooser_salida.setToolTipText("Selecciona fecha de final de validez de entrada");
			dateChooser_salida.setLocale(new Locale("es", "ES"));
			dateChooser_salida.setDateFormatString("dd-MM-yyyy");
		}
		return dateChooser_salida;
	}

	private String calculoFechaInicio() {
		Date fecha = getDateChooser_llegada().getDate();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String f = sdf.format(fecha);
		return f;
	}

	private boolean checkDate() {
		String s = ((JTextField) getDateChooser_salida().getDateEditor().getUiComponent()).getText();
		String ll = ((JTextField) getDateChooser_llegada().getDateEditor().getUiComponent()).getText();

		if (s.equals("") || ll.equals("")
				|| getDateChooser_salida().getDate().before(getDateChooser_llegada().getDate())
				|| calularduracion() == 0)
			return false;
		return true;

	}

	private void saberMasParque() {
		Paquete paquete = agencia.searchPaqueteByParque(tematico.getCodigo());
		SaberMasParqueVentana smpv = new SaberMasParqueVentana(agencia, paquete);
		smpv.setLocationRelativeTo(null);
		smpv.setVisible(true);
	}

	private JButton getBtnVermas() {
		if (btnVermas == null) {
			btnVermas = new JButton("Ver M\u00E1s");
			btnVermas.setToolTipText("Ver m\u00E1s informaci\u00F3n del parque");
			btnVermas.setMnemonic('V');
			btnVermas.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					saberMasParque();
				}
			});
		}
		return btnVermas;
	}
}
