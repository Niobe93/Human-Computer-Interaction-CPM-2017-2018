package igu;

import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.border.SoftBevelBorder;

import logica.Agencia;
import logica.Alojamiento;
import logica.Paquete;
import logica.Reserva;

import javax.swing.border.BevelBorder;
import java.awt.Color;

import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.border.TitledBorder;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class ReservaPaqueteJpane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Reserva paquete;
	private JPanel panel;
	private JPanel panel_nombre;
	private JPanel panel_precio;
	private JPanel panel_adultos;
	private JLabel lblNmeroDePersonas;
	private JSpinner spinner_adultos;
	private JLabel lblNombre;
	private JLabel lblPrecio;
	private JLabel lblNewLabel;
	private JPanel panel_observaciones;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	@SuppressWarnings("unused")
	private Carrito carrito;
	private JPanel panel_ni�os;
	private JLabel lblNmeroDeNios;
	private JSpinner spinner_ni�os;
	private JCheckBox desayuno;
	private JPanel panel_desayuno;
	private Agencia agencia;
	private JPanel panel_ampliable;
	private JSpinner spinner_duracion;
	private JLabel lblDuracinDelPaquete;
	private int duracionOriginal;

	/**
	 * Create the panel.
	 */
	public ReservaPaqueteJpane(Agencia agencia, Reserva paquete, Carrito carrito) {
		this.agencia = agencia;
		this.paquete = paquete;
		this.duracionOriginal= paquete.getDuracion();
		this.carrito = carrito;
		setBackground(new Color(255, 255, 255));
		setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.DARK_GRAY, null, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		add(getPanel());
	    paquete.setNi�os((int) spinner_ni�os.getValue());
		paquete.setAdultos((int) spinner_adultos.getValue());
		paquete.setObservaciones(getTextArea().getText());

	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBorder(new EmptyBorder(0, 0, 0, 0));
			panel.setBackground(Color.WHITE);
			panel.setLayout(new GridLayout(0, 1, 2, 2));
			panel.add(getPanel_nombre());
			panel.add(getPanel_adultos());
			panel.add(getPanel_ni�os());
			panel.add(getPanel_ampliable());
			panel.add(getPanel_precio());
			panel.add(getPanel_desayuno());
			panel.add(getPanel_observaciones());

		}
		return panel;
	}

	private JPanel getPanel_nombre() {
		if (panel_nombre == null) {
			panel_nombre = new JPanel();
			panel_nombre.setBackground(Color.WHITE);
			panel_nombre.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));

			panel_nombre.add(getLblNombre());
		}
		return panel_nombre;
	}

	private JSpinner getSpinner_adultos() {
		if (spinner_adultos == null) {
			spinner_adultos = new JSpinner();
			spinner_adultos.setToolTipText("Selecciona el numero de adultos");
			spinner_adultos.setModel(new SpinnerNumberModel(1, 1, paquete.getPersonas(), 1));
			spinner_adultos.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue(),paquete.getDuracion());
					paquete.setAdultos((int) spinner_adultos.getValue());
					paquete.setPrecio(Double.parseDouble(getLblPrecio().getText()));
				}
			});
			spinner_adultos.setForeground(Color.WHITE);
		}
		return spinner_adultos;
	}

	private JPanel getPanel_precio() {
		if (panel_precio == null) {
			panel_precio = new JPanel();
			panel_precio.setForeground(Color.BLACK);
			panel_precio.setBackground(Color.WHITE);
			panel_precio.add(getLblNewLabel());

			panel_precio.add(getLblPrecio());
		}
		return panel_precio;
	}

	private JPanel getPanel_adultos() {
		if (panel_adultos == null) {
			panel_adultos = new JPanel();
			panel_adultos.setBackground(Color.WHITE);
			panel_adultos.add(getLblNmeroDePersonas());
			panel_adultos.add(getSpinner_adultos());
		}
		return panel_adultos;
	}

	private JLabel getLblNmeroDePersonas() {
		if (lblNmeroDePersonas == null) {
			lblNmeroDePersonas = new JLabel("N\u00FAmero de adultos");
			lblNmeroDePersonas.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return lblNmeroDePersonas;
	}
	
	private void precioNoAmpliable(int adultos, int ni�os) {
		if (getDesayuno().isSelected()) {
			getLblPrecio().setText(String.valueOf((adultos * paquete.getPrecioAdulto() + ni�os * paquete.getPrecioNi�o())
						+ ((adultos * paquete.getPrecioAdulto() + ni�os * paquete.getPrecioNi�o()) * 0.1) + "�"));
			paquete.setDesayuno(true);
	} else {
		getLblPrecio().setText(
				String.valueOf((adultos * paquete.getPrecioAdulto() + ni�os * paquete.getPrecioNi�o()) + "�"));
		paquete.setDesayuno(false);
	}
	}

	public void calcularPrecio(int adultos, int ni�os , int duracion) {
		
		double precioDiaExtraAdultos = adultos * ((paquete.getPrecioAdulto()/duracionOriginal)*1.25);
	    double precioDiaExtraNi�os = ni�os * ((paquete.getPrecioNi�o()/duracionOriginal)*1.25);
	    double precioTotal= adultos * paquete.getPrecioAdulto() + ni�os * paquete.getPrecioNi�o()+(precioDiaExtraAdultos+precioDiaExtraNi�os)*(duracion-duracionOriginal);
	    
		if(!paquete.isAmpliable()||duracionOriginal==duracion)
			precioNoAmpliable(adultos, ni�os);
		else 
			getLblPrecio().setText(String.valueOf(precioTotal));
		

	}

	private JLabel getLblNombre() {
		if (lblNombre == null) {
			lblNombre = new JLabel(paquete.getNombre());
		}
		return lblNombre;
	}

	private JLabel getLblPrecio() {
		if (lblPrecio == null) {
			lblPrecio = new JLabel();
			calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue(), paquete.getDuracion());
		}
		return lblPrecio;
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Total:");
		}
		return lblNewLabel;
	}

	private JPanel getPanel_observaciones() {
		if (panel_observaciones == null) {
			panel_observaciones = new JPanel();
			panel_observaciones.setBackground(Color.WHITE);
			panel_observaciones.setBorder(new TitledBorder(null, "Observaciones:", TitledBorder.LEADING,
					TitledBorder.TOP, null, Color.BLACK));
			panel_observaciones.setLayout(new BorderLayout(0, 0));
			panel_observaciones.add(getScrollPane());
		}
		return panel_observaciones;
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getTextArea());
		}
		return scrollPane;
	}

	private JTextArea getTextArea() {
		if (textArea == null) {
			textArea = new JTextArea();
			textArea.setToolTipText("Escribe las observaciones que quieres realizar con tu reserva");
			textArea.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent arg0) {
					paquete.setObservaciones(getTextArea().getText());
				}
			});
			textArea.setLineWrap(true);

		}
		return textArea;
	}

	private JPanel getPanel_ni�os() {
		if (panel_ni�os == null) {
			panel_ni�os = new JPanel();
			panel_ni�os.setBackground(Color.WHITE);
			panel_ni�os.add(getLblNmeroDeNios());
			panel_ni�os.add(getSpinner_ni�os());
		}
		return panel_ni�os;
	}

	private JLabel getLblNmeroDeNios() {
		if (lblNmeroDeNios == null) {
			lblNmeroDeNios = new JLabel("N\u00FAmero de ni\u00F1os");
			lblNmeroDeNios.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return lblNmeroDeNios;
	}

	private JSpinner getSpinner_ni�os() {
		if (spinner_ni�os == null) {
			spinner_ni�os = new JSpinner();
			spinner_ni�os.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
			spinner_ni�os.setToolTipText("Selecciona el numero de ni\u00F1os");
			spinner_ni�os.setForeground(Color.WHITE);			
			spinner_ni�os.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					spinner_ni�os.repaint();
					calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue(),paquete.getDuracion());
					paquete.setNi�os((int) spinner_ni�os.getValue());
					paquete.setPrecio(Double.parseDouble(getLblPrecio().getText()));
					
				}
			});
			

		}
		return spinner_ni�os;
	}

	private JCheckBox getDesayuno() {
		if (desayuno == null) {
			desayuno = new JCheckBox();
			desayuno.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					
					calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue(),paquete.getDuracion());
					paquete.setPrecio(Double.parseDouble(getLblPrecio().getText()));
				}
			});

		}
		return desayuno;
	}

	private JPanel getPanel_desayuno() {
		if (panel_desayuno == null) {
			panel_desayuno = new JPanel();
			panel_desayuno.setBackground(Color.WHITE);
			Paquete p = agencia.searchPaquete(paquete.getCodigo());
			Alojamiento a = agencia.searchAlojamiento(p.getCodigo_alojamiento());
			if (a.getTipo().equals("HO")) {
				panel_desayuno.add(new JLabel("Desayuno: "));
				panel_desayuno.add(getDesayuno());
				getDesayuno().setVisible(true);
			}
		}
		return panel_desayuno;
	}

	private JPanel getPanel_ampliable() {
		if (panel_ampliable == null) {
			panel_ampliable = new JPanel();
			panel_ampliable.setBackground(Color.WHITE);
			if(paquete.isAmpliable()) {
				panel_ampliable.add(getLblDuracinDelPaquete());
				panel_ampliable.add(getSpinner_duracion());}
		}
		return panel_ampliable;
	}
	private JSpinner getSpinner_duracion() {
		if (spinner_duracion == null) {
			spinner_duracion = new JSpinner();
			spinner_duracion.setModel(new SpinnerNumberModel(duracionOriginal, duracionOriginal, null, new Integer(1)));
			spinner_duracion.setToolTipText("Selecciona el numero de ni\u00F1os");		
			spinner_duracion.setForeground(Color.WHITE);
			spinner_duracion.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {					
					paquete.setDuracion((int) spinner_duracion.getValue());
					calcularPrecio((int) spinner_adultos.getValue(), (int) spinner_ni�os.getValue(),paquete.getDuracion());
					paquete.setPrecio(Double.parseDouble(getLblPrecio().getText()));
					
					
				}
			});
		}
		return spinner_duracion;
	}
	private JLabel getLblDuracinDelPaquete() {
		if (lblDuracinDelPaquete == null) {
			lblDuracinDelPaquete = new JLabel("Duraci\u00F3n ");
			lblDuracinDelPaquete.setFont(new Font("Tahoma", Font.PLAIN, 12));
		}
		return lblDuracinDelPaquete;
	}
}
