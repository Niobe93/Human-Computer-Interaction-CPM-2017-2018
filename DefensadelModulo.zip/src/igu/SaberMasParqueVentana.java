package igu;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import logica.Agencia;
import logica.Paquete;
import logica.Tematico;

import javax.swing.JLabel;
import java.awt.Image;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SaberMasParqueVentana extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JLabel label;
	private String imgPath;
	private Tematico tematico;

	@SuppressWarnings("unused")
	private Agencia agencia;
	@SuppressWarnings("unused")
	private Paquete paquete;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	private JButton btnCerrar;

	/**
	 * Create the frame.
	 * 
	 * @param codigo
	 */
	public SaberMasParqueVentana(Agencia agencia, Paquete paquete) {
		setResizable(false);
		this.agencia = agencia;
		this.paquete = paquete;
		this.tematico = agencia.searchParque(paquete.getCodigo_parque());
		imgPath = "/img/" + tematico.getCodigo() + ".jpg";
		setIconImage(Toolkit.getDefaultToolkit().getImage(SaberMasParqueVentana.class.getResource("/img/logo.jpg")));
		setTitle("Informaci\u00F3n parque tem�tico");
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 500, 238);
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(getLabel(), BorderLayout.WEST);
		getContentPane().add(getScrollPane());
		getContentPane().add(getBtnCerrar(), BorderLayout.SOUTH);

	}

	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("");
			label.setVerticalAlignment(SwingConstants.CENTER);
			label.setBackground(Color.WHITE);
			ImageIcon icon = new ImageIcon(VentanaPrincipal.class.getResource(imgPath));
			Image img = icon.getImage();
			Image redimImg = img.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
			ImageIcon redimIcon = new ImageIcon(redimImg);

			label.setIcon(redimIcon);
			label.setVerticalAlignment(JLabel.CENTER);
		}
		return label;
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getTextArea());
		}
		return scrollPane;
	}

	private JTextArea getTextArea() {
		if (textArea == null) {
			textArea = new JTextArea();
			textArea.setLineWrap(true);
			textArea.setForeground(Color.BLACK);
			textArea.setFont(new Font("Tahoma", Font.PLAIN, 12));
			textArea.setText(tematico.getDescripcion());
			textArea.setBackground(Color.WHITE);
			textArea.setEditable(false);
		}
		return textArea;
	}

	private JButton getBtnCerrar() {
		if (btnCerrar == null) {
			btnCerrar = new JButton("Cerrar");
			btnCerrar.setToolTipText("Cerrar la ventana");
			btnCerrar.setMnemonic('C');
			btnCerrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
		}
		return btnCerrar;
	}
}
