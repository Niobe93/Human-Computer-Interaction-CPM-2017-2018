package igu;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.toedter.calendar.JCalendar;

import logica.Agencia;
import logica.Alojamiento;
import logica.Paquete;
import logica.Tematico;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JSlider;
import java.awt.Cursor;

import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.awt.event.ActionEvent;

import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;

public class VentanaPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panel;
	private JPanel panel_Norte;
	private JButton btnLogo;
	private JPanel panel_Filtros;
	private JPanel panel_Tipo;
	private JPanel panel_Categoria;
	private JSlider slider_categoria;
	private JPanel panel_Precio;
	private JSlider slider_precio;
	private JScrollPane scrollPpal;
	@SuppressWarnings("unused")
	private JCalendar calendario;

	private Agencia agencia = new Agencia();
	private ArrayList<Paquete> paquetes;
	private ArrayList<Tematico> tematicos;

	private JComboBox<String> comboBox_Tipo;
	private JTabbedPane tabbedPane_PV;
	private JPanel panel_ppal;
	private JPanel panel_DyL;
	private JSpinner spinner;
	private JComboBox<String> comboBox;
	private JPanel panel_duracion;
	private JPanel panel_Localidad;
	private JScrollPane scrollAlojamientos;
	private JPanel panel_alojamientos;
	private ArrayList<Alojamiento> alojamientos;
	private JScrollPane scrollParques;
	private JPanel panel_parques;

	private Carrito carrito;
	private JPanel panel_carrito;
	private JButton btncarrito;
	private JPanel panel_sur;
	private JLabel lblcopyright;
	private JMenuBar menuBar;
	private JMenu mnHome;
	private JMenuItem mntmReiniciar;
	private JSeparator separator;
	private JMenuItem mntmSalir;
	private JMenu mnAcercade;
	private JMenuItem mntmContenido;
	private JSeparator separator_1;
	private JMenuItem mntmAcercaDe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrame.setDefaultLookAndFeelDecorated(true);
					UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {

		carrito = new Carrito(this, agencia);
		setBackground(Color.WHITE);
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logo.jpg")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1300, 525);
		setLocationRelativeTo(null);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(getPanel(), BorderLayout.CENTER);
		contentPane.add(getPanel_sur(), BorderLayout.SOUTH);
		initPaquetes();
		initAlojamientos();
		initParques();
		cargaAyuda();

	}

	private void cargaAyuda() {

		URL hsURL;
		HelpSet hs;

		try {
			File fichero = new File("help/Ayuda.hs");
			hsURL = fichero.toURI().toURL();
			hs = new HelpSet(null, hsURL);
		}

		catch (Exception e) {
			System.out.println("Ayuda no encontrada");
			return;
		}

		HelpBroker hb = hs.createHelpBroker();
		hb.initPresentation();

		hb.enableHelpKey(getRootPane(), "introduccion", hs);
		hb.enableHelpOnButton(mntmContenido, "introduccion", hs);

	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(Color.WHITE);
			panel.setLayout(new BorderLayout(0, 0));
			panel.add(getPanel_Norte(), BorderLayout.NORTH);
			panel.add(getPanel_Filtros(), BorderLayout.WEST);
			panel.add(getTabbedPane_PV(), BorderLayout.CENTER);
		}
		return panel;
	}

	private JPanel getPanel_Norte() {
		if (panel_Norte == null) {
			panel_Norte = new JPanel();
			panel_Norte.setBorder(null);
			panel_Norte.setBackground(Color.WHITE);
			panel_Norte.setLayout(new BoxLayout(panel_Norte, BoxLayout.X_AXIS));
			panel_Norte.add(getBtnLogo());
			panel_Norte.add(getPanel_carrito());
		}
		return panel_Norte;
	}

	private JButton getBtnLogo() {
		if (btnLogo == null) {
			btnLogo = new JButton("");
			btnLogo.setContentAreaFilled(false);
			btnLogo.setRequestFocusEnabled(false);
			btnLogo.setVerifyInputWhenFocusTarget(false);
			btnLogo.setRolloverEnabled(false);
			btnLogo.setFocusPainted(false);
			btnLogo.setFocusTraversalKeysEnabled(false);
			btnLogo.setFocusable(false);
			btnLogo.setHorizontalAlignment(SwingConstants.LEADING);
			btnLogo.setBorder(new LineBorder(new Color(255, 255, 255), 5, true));
			btnLogo.setBackground(Color.WHITE);
			btnLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.jpg")));
		}
		return btnLogo;
	}

	private JPanel getPanel_Filtros() {
		if (panel_Filtros == null) {
			panel_Filtros = new JPanel();
			panel_Filtros.setBackground(new Color(255, 255, 255));
			panel_Filtros.setLayout(new GridLayout(0, 1, 0, 0));
			panel_Filtros.add(getPanel_Tipo());
			panel_Filtros.add(getPanel_Precio());
			panel_Filtros.add(getPanel_Categoria());
			panel_Filtros.add(getPanel_DyL());
		}
		return panel_Filtros;
	}

	private JPanel getPanel_Tipo() {
		if (panel_Tipo == null) {
			panel_Tipo = new JPanel();
			panel_Tipo.setForeground(new Color(0, 0, 0));
			panel_Tipo.setBackground(new Color(255, 255, 255));
			panel_Tipo.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Alojamiento",
					TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_Tipo.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			panel_Tipo.add(getComboBox_Tipo());
		}
		return panel_Tipo;
	}

	private JPanel getPanel_Categoria() {
		if (panel_Categoria == null) {
			panel_Categoria = new JPanel();
			panel_Categoria.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			panel_Categoria.setBackground(new Color(255, 255, 255));
			panel_Categoria.add(getSlider_categoria());
		}
		return panel_Categoria;
	}

	private JSlider getSlider_categoria() {
		if (slider_categoria == null) {
			slider_categoria = new JSlider();
			slider_categoria.setToolTipText("Selecciona la categor\u00EDa del alojamiento");
			slider_categoria.setForeground(new Color(0, 0, 0));
			slider_categoria.setBackground(new Color(255, 255, 255));
			slider_categoria.setSnapToTicks(true);
			slider_categoria.setMajorTickSpacing(1);
			slider_categoria.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Categor\u00EDa",
					TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			slider_categoria.setValue(5);
			slider_categoria.setPaintTicks(true);
			slider_categoria.setPaintLabels(true);
			slider_categoria.setMinorTickSpacing(1);
			slider_categoria.setMinimum(1);
			slider_categoria.setMaximum(5);
			slider_categoria.repaint();
			slider_categoria.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					slider_categoria.repaint();
					loadPaquetes(agencia.paqueteByCategoria((int) slider_categoria.getValue()));
					slider_categoria.repaint();
					loadAlojamientos(agencia.alojamientoByCategoria((int) slider_categoria.getValue()));
					slider_categoria.repaint();

				}
			});
		}
		return slider_categoria;
	}

	private JPanel getPanel_Precio() {
		if (panel_Precio == null) {
			panel_Precio = new JPanel();
			panel_Precio.setBackground(new Color(255, 255, 255));
			panel_Precio.setBorder(null);
			panel_Precio.add(getSlider_precio());
		}
		return panel_Precio;
	}

	private JSlider getSlider_precio() {
		if (slider_precio == null) {
			slider_precio = new JSlider();
			slider_precio.setToolTipText("Selecciona el rango de precio");
			slider_precio.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			slider_precio.setForeground(new Color(0, 0, 0));
			slider_precio.setBackground(new Color(255, 255, 255));
			slider_precio.setMaximum(1250);
			slider_precio.setValue(1250);
			slider_precio.setSnapToTicks(true);
			slider_precio.setPaintTicks(true);
			slider_precio.setPaintLabels(true);
			slider_precio.setMinorTickSpacing(100);
			slider_precio.setMinimum(100);
			slider_precio.setMajorTickSpacing(200);
			slider_precio.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Precio",
					TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			slider_precio.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					slider_precio.repaint();
					loadPaquetes(agencia.paqueteByPrecio(slider_precio.getValue()));
					slider_precio.repaint();
					loadAlojamientos(agencia.alojamientoByPrecio(slider_precio.getValue()));
					slider_precio.repaint();

				}
			});
		}

		return slider_precio;
	}

	private JScrollPane getScrollPpal() {
		if (scrollPpal == null) {
			scrollPpal = new JScrollPane();
			scrollPpal.setBackground(Color.WHITE);
			scrollPpal.setViewportView(getPanel_ppal());
		}
		return scrollPpal;
	}

	private void initPaquetes() {
		panel_ppal.removeAll();
		paquetes = agencia.getPaquetes();
		for (Paquete p : paquetes) {
			PaqueteJpane paqueteJPane = new PaqueteJpane(agencia, p, carrito);
			panel_ppal.add(paqueteJPane);
		}
		revalidate();
		repaint();
	}

	private void initAlojamientos() {
		panel_alojamientos.removeAll();
		alojamientos = agencia.getAlojamientos();
		for (Alojamiento a : alojamientos) {
			AlojamientoJpane aJPane = new AlojamientoJpane(a, carrito);
			panel_alojamientos.add(aJPane);
		}
		revalidate();
		repaint();
	}

	private void initParques() {
		panel_parques.removeAll();
		tematicos = agencia.getTematicos();
		for (Tematico t : tematicos) {
			TematicoJpane tJPane = new TematicoJpane(t, agencia, carrito);
			panel_parques.add(tJPane);
		}
		revalidate();
		repaint();
	}

	private void loadPaquetes(ArrayList<Paquete> paquetes) {
		panel_ppal.removeAll();
		for (int i = 0; i < paquetes.size(); i++) {
			PaqueteJpane pPane = new PaqueteJpane(agencia, paquetes.get(i), carrito);
			panel_ppal.add(pPane);
		}
		revalidate();
		repaint();
	}

	private void loadAlojamientos(ArrayList<Alojamiento> alojamientos) {
		panel_alojamientos.removeAll();
		for (int i = 0; i < alojamientos.size(); i++) {
			AlojamientoJpane aPane = new AlojamientoJpane(alojamientos.get(i), carrito);
			panel_alojamientos.add(aPane);
		}
		revalidate();
		repaint();
	}

	private void loadParques(ArrayList<Tematico> tematicos) {
		panel_parques.removeAll();
		for (int i = 0; i < tematicos.size(); i++) {
			TematicoJpane tPane = new TematicoJpane(tematicos.get(i), agencia, carrito);
			panel_parques.add(tPane);
		}
		revalidate();
		repaint();
	}

	private JComboBox<String> getComboBox_Tipo() {
		if (comboBox_Tipo == null) {
			comboBox_Tipo = new JComboBox<String>();
			comboBox_Tipo.setToolTipText("Selecciona el tipo de alojamiento");
			comboBox_Tipo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (comboBox_Tipo.getSelectedItem() == "Hotel") {
						loadPaquetes(agencia.searchPaquetesByTipo("HO"));
						loadAlojamientos(agencia.searchAlojamientoByTipo("HO"));
					}

					else if (comboBox_Tipo.getSelectedItem() == "ApartaHotel") {
						loadPaquetes(agencia.searchPaquetesByTipo("AH"));
						loadAlojamientos(agencia.searchAlojamientoByTipo("AH"));
					}

					else if (comboBox_Tipo.getSelectedItem() == "Apartamento") {
						loadPaquetes(agencia.searchPaquetesByTipo("AP"));
						loadAlojamientos(agencia.searchAlojamientoByTipo("AP"));
					} else {
						initPaquetes();
						initAlojamientos();
					}

				}
			});
			comboBox_Tipo.setModel(
					new DefaultComboBoxModel<String>(new String[] { "Todos", "Hotel", "ApartaHotel", "Apartamento" }));
		}
		return comboBox_Tipo;
	}

	private JTabbedPane getTabbedPane_PV() {
		if (tabbedPane_PV == null) {
			tabbedPane_PV = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane_PV.setFont(new Font("Tahoma", Font.BOLD, 12));
			tabbedPane_PV.setBackground(Color.WHITE);
			tabbedPane_PV.addTab("Paquetes Vacacionales", null, getScrollPpal(), null);
			tabbedPane_PV.addTab("Alojamientos", null, getScrollAlojamientos(), null);
			tabbedPane_PV.addTab("Parques Tem�ticos", null, getScrollParques(), null);
		}
		return tabbedPane_PV;
	}

	private JPanel getPanel_ppal() {
		if (panel_ppal == null) {
			panel_ppal = new JPanel();
			panel_ppal.setBackground(Color.WHITE);
			panel_ppal.setLayout(new GridLayout(6, 2, 0, 0));
		}
		return panel_ppal;
	}

	private JPanel getPanel_DyL() {
		if (panel_DyL == null) {
			panel_DyL = new JPanel();
			panel_DyL.setBackground(Color.WHITE);
			panel_DyL.setBorder(null);
			panel_DyL.setLayout(new GridLayout(0, 2, 0, 0));
			panel_DyL.add(getPanel_1_2());
			panel_DyL.add(getPanel_1_3());
		}
		return panel_DyL;
	}

	private JSpinner getSpinner() {
		if (spinner == null) {
			spinner = new JSpinner();
			spinner.setToolTipText("Selecciona la duraci\u00F3n del paquete vacacional");
			spinner.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					loadPaquetes(agencia.paqueteByDuracion((int) spinner.getValue()));

				}
			});
			spinner.setBackground(Color.WHITE);
			spinner.setModel(new SpinnerNumberModel(4, 2, 4, 1));
			spinner.setForeground(Color.WHITE);
		}
		return spinner;
	}

	private JComboBox<String> getComboBox() {
		if (comboBox == null) {
			comboBox = new JComboBox<String>();
			comboBox.setToolTipText("Selecciona la localidad");
			comboBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (comboBox.getSelectedItem() == "Espa�a") {
						loadParques(agencia.searchParqueByLocation("Espa�a"));
						loadAlojamientos(agencia.searchAlojamientoByLocation("Espa�a"));
						loadPaquetes(agencia.searchPaqueteByLocation("Espa�a"));
					} else if (comboBox.getSelectedItem() == "Inglaterra") {
						loadParques(agencia.searchParqueByLocation("Inglaterra"));
						loadAlojamientos(agencia.searchAlojamientoByLocation("Inglaterra"));
						loadPaquetes(agencia.searchPaqueteByLocation("Inglaterra"));

					} else if (comboBox.getSelectedItem() == "Francia") {
						loadParques(agencia.searchParqueByLocation("Francia"));
						loadAlojamientos(agencia.searchAlojamientoByLocation("Francia"));
						loadPaquetes(agencia.searchPaqueteByLocation("Francia"));

					} else {
						initParques();
						initAlojamientos();
						initPaquetes();
					}

				}
			});
			comboBox.setModel(
					new DefaultComboBoxModel<String>(new String[] { "Todas", "Espa\u00F1a", "Francia", "Inglaterra" }));
			comboBox.setBackground(Color.WHITE);
		}
		return comboBox;
	}

	private JPanel getPanel_1_2() {
		if (panel_duracion == null) {
			panel_duracion = new JPanel();
			panel_duracion.setBackground(Color.WHITE);
			panel_duracion.setBorder(
					new TitledBorder(null, "Duraci\u00F3n", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLACK));
			panel_duracion.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			panel_duracion.add(getSpinner());
		}
		return panel_duracion;
	}

	private JPanel getPanel_1_3() {
		if (panel_Localidad == null) {
			panel_Localidad = new JPanel();
			panel_Localidad.setBorder(new TitledBorder(null, "Localizaci\u00F3n", TitledBorder.LEADING,
					TitledBorder.TOP, null, Color.BLACK));
			panel_Localidad.setBackground(Color.WHITE);
			panel_Localidad.add(getComboBox());
		}
		return panel_Localidad;
	}

	private JScrollPane getScrollAlojamientos() {
		if (scrollAlojamientos == null) {
			scrollAlojamientos = new JScrollPane();
			scrollAlojamientos.setViewportView(getPanel_alojamientos());
		}
		return scrollAlojamientos;
	}

	private JPanel getPanel_alojamientos() {
		if (panel_alojamientos == null) {
			panel_alojamientos = new JPanel();
			panel_alojamientos.setBackground(Color.WHITE);
			panel_alojamientos.setLayout(new GridLayout(7, 3, 0, 0));
		}
		return panel_alojamientos;
	}

	private JScrollPane getScrollParques() {
		if (scrollParques == null) {
			scrollParques = new JScrollPane();
			scrollParques.setViewportView(getPanel_parques());
		}
		return scrollParques;
	}

	private JPanel getPanel_parques() {
		if (panel_parques == null) {
			panel_parques = new JPanel();
			panel_parques.setBackground(Color.WHITE);
			panel_parques.setLayout(new GridLayout(3, 3, 0, 0));
		}
		return panel_parques;
	}

	private JPanel getPanel_carrito() {
		if (panel_carrito == null) {
			panel_carrito = new JPanel();
			panel_carrito.setBackground(Color.WHITE);
			panel_carrito.setLayout(new BorderLayout(0, 0));
			panel_carrito.add(getBtncarrito(), BorderLayout.EAST);
		}
		return panel_carrito;
	}

	private JButton getBtncarrito() {
		if (btncarrito == null) {
			btncarrito = new JButton("Tus reservas");
			btncarrito.setToolTipText("Carrito de la compra");
			btncarrito.setMnemonic('C');
			btncarrito.setFont(new Font("Tahoma", Font.BOLD, 12));
			btncarrito.setHorizontalTextPosition(SwingConstants.LEADING);
			btncarrito.setVerticalAlignment(SwingConstants.BOTTOM);
			btncarrito.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					carrito.setLocationRelativeTo(null);
					carrito.setVisible(true);
				}
			});
			btncarrito.setContentAreaFilled(false);
			btncarrito.setBorderPainted(false);
			btncarrito.setBackground(Color.WHITE);
			ImageIcon icon = new ImageIcon(VentanaPrincipal.class.getResource("/img/carrito.jpg"));
			Image img = icon.getImage();
			Image redimImg = img.getScaledInstance(25, 25, Image.SCALE_SMOOTH);
			ImageIcon redimIcon = new ImageIcon(redimImg);
			btncarrito.setIcon(redimIcon);

		}
		return btncarrito;
	}

	public void inicializar() {
		agencia = new Agencia();
		carrito = new Carrito(this, agencia);
		initPaquetes();
		initAlojamientos();
		initParques();

	}

	private JPanel getPanel_sur() {
		if (panel_sur == null) {
			panel_sur = new JPanel();
			panel_sur.setBackground(Color.WHITE);
			panel_sur.setLayout(new GridLayout(1, 0, 0, 0));
			panel_sur.add(getLblcopyright());
		}
		return panel_sur;
	}

	private JLabel getLblcopyright() {
		if (lblcopyright == null) {
			lblcopyright = new JLabel("Aviso de Copyright\r\n\r\nCopyright \u00A9 2018 Logo.es");
		}
		return lblcopyright;
	}

	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnHome());
			menuBar.add(getMnAcercade());
		}
		return menuBar;
	}

	private JMenu getMnHome() {
		if (mnHome == null) {
			mnHome = new JMenu("Ventana");
			mnHome.setMnemonic('V');
			mnHome.add(getMntmReiniciar());
			mnHome.add(getSeparator());
			mnHome.add(getMntmSalir());
		}
		return mnHome;
	}

	private JMenuItem getMntmReiniciar() {
		if (mntmReiniciar == null) {
			mntmReiniciar = new JMenuItem("Reiniciar ");
			mntmReiniciar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
			mntmReiniciar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar();
				}
			});
		}
		return mntmReiniciar;
	}

	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}

	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0));
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
		}
		return mntmSalir;
	}

	private JMenu getMnAcercade() {
		if (mnAcercade == null) {
			mnAcercade = new JMenu("Ayuda");
			mnAcercade.setMnemonic('A');
			mnAcercade.add(getMntmContenido());
			mnAcercade.add(getSeparator_1());
			mnAcercade.add(getMntmAcercaDe());
		}
		return mnAcercade;
	}

	private JMenuItem getMntmContenido() {
		if (mntmContenido == null) {
			mntmContenido = new JMenuItem("Contenido");
			mntmContenido.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
		}
		return mntmContenido;
	}

	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}

	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca de");
			mntmAcercaDe.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F8, InputEvent.CTRL_MASK));
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null,
							"Esta aplicaci�n ha sido desarrollada por Gema Rico Pozas para el m�dulo de pr�cticas de CPM 2017-2018");
				}
			});
		}
		return mntmAcercaDe;
	}
}
