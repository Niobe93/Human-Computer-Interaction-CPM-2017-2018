package logica;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class Agencia {

	private static final String ALOJAMIENTOS_FILEPATH = "files/alojamientos.dat";
	private static final String PAQUETES_FILEPATH = "files/paquetes.dat";
	private static final String TEMATICOS_FILEPATH = "files/tematicos.dat";
	private static final String COMPLETOS_FILEPATH = "files/completos.dat";
	private static final String ENTRADAS_FILEPATH = "files/entradas.dat";

	private ArrayList<Alojamiento> alojamientos;
	private ArrayList<Tematico> tematicos;
	private ArrayList<Tematico> completos;
	private ArrayList<Paquete> paquetes;
	private ArrayList<Entrada> entradas;

	public Agencia() {

		alojamientos = new ArrayList<Alojamiento>();
		completos = new ArrayList<Tematico>();
		tematicos = new ArrayList<Tematico>();
		paquetes = new ArrayList<Paquete>();
		entradas = new ArrayList<Entrada>();
		loadPaquetes();
		loadTematicos();
		loadAlojamientos();
		loadEntradas();
		loadCompletos();
		changeCompletos();

	}

	private void loadAlojamientos() {
		String line = "";
		String[] data = new String[7];
		try {
			BufferedReader f = new BufferedReader(new FileReader(ALOJAMIENTOS_FILEPATH));
			while (f.ready()) {
				line = f.readLine();
				data = line.split("@");
				alojamientos.add(new Alojamiento(data[0], data[1], data[2], data[3], data[4], Integer.parseInt(data[5]),
						Double.parseDouble(data[6])));
			}
			f.close();
		} catch (FileNotFoundException e) {
			System.err.println("No se ha encontrado el archivo");
		} catch (IOException ioe) {
			new RuntimeException("Error E/S");
		}
	}

	private void loadEntradas() {
		String line = "";
		String[] data = new String[4];
		try {
			BufferedReader f = new BufferedReader(new FileReader(ENTRADAS_FILEPATH));
			while (f.ready()) {
				line = f.readLine();
				data = line.split("@");
				entradas.add(new Entrada(data[0], data[1], Double.parseDouble(data[2]), Double.parseDouble(data[3])));
			}
			f.close();
		} catch (FileNotFoundException e) {
			System.err.println("No se ha encontrado el archivo");
		} catch (IOException ioe) {
			new RuntimeException("Error E/S");
		}
	}

	private void loadTematicos() {
		String line = "";
		String[] data = new String[5];
		try {
			BufferedReader f = new BufferedReader(new FileReader(TEMATICOS_FILEPATH));
			while (f.ready()) {
				line = f.readLine();
				data = line.split("@");
				tematicos.add(new Tematico(data[0], data[1], data[2], data[3], data[4],true));
			}
			f.close();
		} catch (FileNotFoundException e) {
			System.err.println("No se ha encontrado el archivo");
		} catch (IOException ioe) {
			new RuntimeException("Error E/S");
		}
	}

	private void loadPaquetes() {
		String line = "";
		String[] data = new String[8];
		try {
			BufferedReader f = new BufferedReader(new FileReader(PAQUETES_FILEPATH));
			while (f.ready()) {
				line = f.readLine();
				data = line.split("@");
				paquetes.add(new Paquete(data[0], data[1], data[2], data[3], Integer.parseInt(data[4]),
						Boolean.valueOf(data[5]),Double.parseDouble(data[6]), Double.parseDouble(data[7])));

			}
			f.close();
		} catch (FileNotFoundException e) {
			System.err.println("No se ha encontrado el archivo");
		} catch (IOException ioe) {
			new RuntimeException("Error E/S");
		}
	}
	
	private void loadCompletos() {
		String line = "";
		String[] data = new String[5];
		try {
			BufferedReader f = new BufferedReader(new FileReader(COMPLETOS_FILEPATH));
			while (f.ready()) {
				line = f.readLine();
				data = line.split("@");
				completos.add(new Tematico(data[0], data[1], data[2], data[3], data[4],false));

			}
			f.close();
			
		} catch (FileNotFoundException e) {
			System.err.println("No se ha encontrado el archivo");
		} catch (IOException ioe) {
			new RuntimeException("Error E/S");
		}
	}
	
	public void changeCompletos() {
		
		for(Tematico t : tematicos) {
			for(Tematico t2 : completos) {
				if(t.getCodigo().equals(t2.getCodigo()))
					t.setDisponible(false);
		}}
		
	}

	public Alojamiento searchAlojamiento(String codigo) {
		for (int i = 0; i < alojamientos.size(); i++) {
			if (codigo.equals(alojamientos.get(i).getCodigo())) {
				return alojamientos.get(i);
			}
		}
		return null;
	}

	public Paquete searchPaquete(String codigo) {
		for (int i = 0; i < paquetes.size(); i++) {
			if (codigo.equals(paquetes.get(i).getCodigo())) {
				return paquetes.get(i);
			}
		}
		return null;
	}

	public Paquete searchPaqueteByParque(String codigo) {
		for (int i = 0; i < paquetes.size(); i++) {
			if (codigo.equals(paquetes.get(i).getCodigo_parque())) {
				return paquetes.get(i);
			}
		}
		return null;
	}

	public Tematico searchParque(String codigo) {
		for (int i = 0; i < tematicos.size(); i++) {
			if (codigo.equals(tematicos.get(i).getCodigo())) {
				return tematicos.get(i);
			}
		}
		return null;
	}

	public ArrayList<Paquete> searchPaquetesByTipo(String codigo) {
		ArrayList<Paquete> f = new ArrayList<Paquete>();
		for (Paquete p : paquetes) {
			Alojamiento a = searchAlojamiento(p.getCodigo_alojamiento());
			if (a != null && a.getTipo().equals(codigo)) {
				f.add(p);
			}
		}

		return f;
	}

	public ArrayList<Alojamiento> searchAlojamientoByTipo(String codigo) {
		ArrayList<Alojamiento> f = new ArrayList<Alojamiento>();
		for (Alojamiento a : alojamientos) {
			if (a != null && a.getTipo().equals(codigo)) {
				f.add(a);
			}
		}

		return f;
	}

	public ArrayList<Tematico> searchParqueByLocation(String codigo) {
		ArrayList<Tematico> f = new ArrayList<Tematico>();
		for (Tematico t : tematicos) {
			if (t != null && t.getPais().equals(codigo)) {
				f.add(t);
			}
		}

		return f;
	}

	public String searchParqueByPaquete(String codigo_paquete) {
		String nombre = "";
		for (Paquete p : paquetes) {
			if (p != null && p.getCodigo().equals(codigo_paquete))
				nombre = searchParque(p.getCodigo_parque()).getDenominacion();
		}
		return nombre;
	}

	public ArrayList<Alojamiento> searchAlojamientoByLocation(String codigo) {
		ArrayList<Alojamiento> f = new ArrayList<Alojamiento>();
		Tematico t = null;
		for (Alojamiento a : alojamientos) {
			if (a != null)
				t = searchParque(a.getCodigo_parque());
			if (t.getPais().equals(codigo)) {
				f.add(a);
			}
		}

		return f;
	}

	public ArrayList<Paquete> searchPaqueteByLocation(String codigo) {
		ArrayList<Paquete> f = new ArrayList<Paquete>();
		Tematico t = null;
		for (Paquete p : paquetes) {
			if (p != null)
				t = searchParque(p.getCodigo_parque());
			if (t.getPais().equals(codigo)) {
				f.add(p);
			}
		}

		return f;
	}

	public Entrada searchEntradaByParque(String codigo) {
		for (Entrada a : entradas) {
			if (a != null && a.getCodigo_parque().equals(codigo))
				return a;
		}
		return null;
	}

	public Tematico searchParqueByEntrada(String codigo) {
		for (Entrada a : entradas) {
			if (a != null && a.getCodigo().equals(codigo))
				return searchParque(a.getCodigo_parque());
		}
		return null;
	}

	public ArrayList<Paquete> paqueteByCategoria(int value) {
		ArrayList<Paquete> f = new ArrayList<Paquete>();
		for (int i = 0; i < paquetes.size(); i++) {
			Alojamiento a = searchAlojamiento(paquetes.get(i).getCodigo_alojamiento());
			if (Integer.parseInt(a.getCategoria()) <= (value))
				f.add(paquetes.get(i));

		}
		return f;

	}

	public ArrayList<Paquete> paqueteByDuracion(int value) {
		ArrayList<Paquete> f = new ArrayList<Paquete>();
		for (int i = 0; i < paquetes.size(); i++) {
			if (paquetes.get(i).getDuracion() == (value))
				f.add(paquetes.get(i));

		}
		return f;

	}

	public ArrayList<Alojamiento> alojamientoByCategoria(int value) {
		ArrayList<Alojamiento> f = new ArrayList<Alojamiento>();
		for (int i = 0; i < alojamientos.size(); i++) {
			if (Integer.parseInt(alojamientos.get(i).getCategoria()) <= (value))
				f.add(alojamientos.get(i));

		}
		return f;
	}

	public ArrayList<Alojamiento> alojamientoByPrecio(int value) {
		ArrayList<Alojamiento> f = new ArrayList<Alojamiento>();
		for (int i = 0; i < alojamientos.size(); i++) {
			if (alojamientos.get(i).getPrecio() <= (value))
				f.add(alojamientos.get(i));

		}
		return f;
	}

	public ArrayList<Paquete> paqueteByPrecio(int value) {
		ArrayList<Paquete> f = new ArrayList<Paquete>();
		for (int i = 0; i < paquetes.size(); i++) {
			Alojamiento a = searchAlojamiento(paquetes.get(i).getCodigo_alojamiento());
			if (a.getPrecio() <= (value))
				f.add(paquetes.get(i));

		}
		return f;

	}

	public ArrayList<Paquete> getPaquetes() {
		return paquetes;
	}

	public ArrayList<Alojamiento> getAlojamientos() {
		return alojamientos;
	}

	public ArrayList<Tematico> getTematicos() {
		return tematicos;
	}

	public ArrayList<Entrada> getEntradas() {
		return entradas;
	}

	private String getFechayHora() {
		String fecha = "";
		Calendar currentTime = new GregorianCalendar(TimeZone.getDefault());
		int a�o = currentTime.get(Calendar.YEAR);
		int mes = currentTime.get(Calendar.MONTH);
		int dia = currentTime.get(Calendar.DAY_OF_MONTH);
		int hora = currentTime.get(Calendar.HOUR_OF_DAY);
		int min = currentTime.get(Calendar.MINUTE);
		int seg = currentTime.get(Calendar.SECOND);
		fecha += "Realizada la reserva ";
		fecha += "en: " + dia + "/" + (mes + 1) + "/" + a�o;
		fecha += " a las: " + hora + ":" + min + ":" + seg;

		return fecha;
	}

	public String getFactura(String nombre, String DNI, ArrayList<Reserva> reservas) {
		Double precioPaquetes = 0.0;
		Double precioEntradas = 0.0;
		Double precioAlojamientos = 0.0;
		String factura = "";
		factura += "JUSTIFICANTE RESERVA - LOGO.ES VACACIONES - " + getFechayHora() + "\n\n";
		factura += "-------------------------------------------------------------------------------\n";
		factura += "(" + DNI + " - " + nombre + ")" + "\n\n";
		factura += "****DATOS DE LA/S RESERVA/S****\n\n";
		factura += "** PAQUETES TEMATICOS**\n";
		for (Reserva r : reservas) {
			if (r.getTipo().equals("Paquete")) {
				factura += "Paquete: " + r.getCodigo() + " / " + r.getNombre() + " / "
						+ (this.searchParqueByPaquete(r.getCodigo())) + " / " + r.getDuracion() + "\n";
				factura += "N. Adultos: " + r.getAdultos() + " / " + " N. Ni�os: " + r.getNi�os() + "\n";
				if(r.isAmpliable()) {
					factura += "D�as extra parques tem�ticos: " + (r.getDuracion()-searchPaquete(r.getCodigo()).getDuracion())+ "\n";
					precioPaquetes +=r.getPrecio();
					factura += "Observaciones: " + r.getObservaciones() + "\n\n";
				}
				else {
					factura += "Observaciones: " + r.getObservaciones() + "\n\n";
					precioPaquetes += r.getAdultos() * r.getPrecioAdulto() + r.getNi�os() * r.getPrecioNi�o();
				}
				
				
			}
		}

		factura += "** ALOJAMIENTOS**\n\n";
		for (Reserva r : reservas) {
			if (r.getTipo() != "Entrada" && r.getTipo() != "Paquete") {
				factura += "Alojamiento: " + r.getCodigo() + " / " + r.getTipo() + " / " + " / " + r.getNombre() + " / "
						+ searchAlojamiento(r.getCodigo()).getCategoria() + " estrellas / "
						+ searchParque(searchAlojamiento(r.getCodigo()).getCodigo_parque()).getDenominacion() + " / ";
				if (r.getTipo().equals("HO")) {
					if (r.isDesayuno()) {
						factura += "Desayuno : S� \n";
						precioAlojamientos += r.getAdultos() * r.getPrecio() * r.getDuracion() * 0.1
								+ r.getAdultos() * r.getPrecio() * r.getDuracion();
					} else {
						precioAlojamientos += r.getAdultos() * r.getPrecio() * r.getDuracion();
						factura += "Desayuno : No \n";
					}
				}

				factura += "Fecha inicio: " + r.getFechaInicio() + " / " + "N�mero de noches: " + r.getDuracion()
						+ " / Numero de personas: " + r.getAdultos() + " / " + "\n\n";
				factura += "Observaciones: " + r.getObservaciones() + "\n\n";
				if (r.getTipo().equals("AP") || r.getTipo().equals("AH"))
					precioAlojamientos += r.getPrecio() * r.getDuracion();
			}
		}
		factura += "** ENTRADAS **\n\n";
		for (Reserva r : reservas) {
			if (r.getTipo().equals("Entrada")) {
				factura += "Entrada: " + r.getCodigo() + " / "
						+ (this.searchParqueByEntrada(r.getCodigo())).getDenominacion() + " / " + r.getDuracion()
						+ "\n";
				factura += "N. Adultos: " + r.getAdultos() + " / " + " N. Ni�os: " + r.getNi�os() + "\n\n";

				precioEntradas += r.getPrecioAdulto() * r.getAdultos() + r.getPrecioNi�o() * r.getNi�os();
			}
		}

		factura += "**** PAGADO RESERVA ****" + "\n\n";

		factura += "Paquetes tem�ticos:					 " + String.valueOf(precioPaquetes) + " �" + "\n\n";
		factura += "Alojamientos:					 " + String.valueOf(precioAlojamientos) + " �" + "\n\n";
		factura += "Entradas: 						" + String.valueOf(precioEntradas) + " �" + "\n\n";
		
				
		
			factura += "Importe Total:					 "
					+ String.valueOf(precioPaquetes + precioAlojamientos + precioEntradas) + " �" + "\n";

		return factura;
	}
	
	
	

	public void generarFactura(String nombre, String DNI, ArrayList<Reserva> reservas) {
		FileWriter file = null;
		PrintWriter pw = null;

		try {
			file = new FileWriter("reservas/" + DNI + ".txt");
			pw = new PrintWriter(file);
			String toWrite = getFactura(nombre, DNI, reservas);
			for (int i = 0; i < toWrite.split("\n").length; i++) {
				pw.println(toWrite.split("\n")[i]);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (file != null)
					file.close();
			} catch (Exception er) {
				er.printStackTrace();
			}
		}
	}

}
