package logica;

public class Paquete {

	private String codigo;
	private String denominacion;
	private String codigo_parque;
	private String codigo_alojamiento;
	private int duracion;
	private double precio_adulto;
	private double precio_ni�o;
	private boolean ampliable;

	public Paquete(String codigo, String denominacion, String codigo_parque, String codigo_alojamiento, int duracion,
			boolean ampliable,double precio_adulto, double precio_ni�o) {
		super();
		this.codigo = codigo;
		this.setAmpliable(ampliable);
		this.denominacion = denominacion;
		this.codigo_parque = codigo_parque;
		this.codigo_alojamiento = codigo_alojamiento;
		this.duracion = duracion;
		this.precio_adulto = precio_adulto;
		this.precio_ni�o = precio_ni�o;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDenominacion() {
		return denominacion;
	}

	public void setDenominacion(String denominacion) {
		this.denominacion = denominacion;
	}

	public String getCodigo_parque() {
		return codigo_parque;
	}

	public void setCodigo_parque(String codigo_parque) {
		this.codigo_parque = codigo_parque;
	}

	public String getCodigo_alojamiento() {
		return codigo_alojamiento;
	}

	public void setCodigo_alojamiento(String codigo_alojamiento) {
		this.codigo_alojamiento = codigo_alojamiento;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public double getPrecio_adulto() {
		return precio_adulto;
	}

	public void setPrecio_adulto(double precio_adulto) {
		this.precio_adulto = precio_adulto;
	}

	public double getPrecio_ni�o() {
		return precio_ni�o;
	}

	public void setPrecio_ni�o(double precio_ni�o) {
		this.precio_ni�o = precio_ni�o;
	}

	public boolean isAmpliable() {
		return ampliable;
	}

	public void setAmpliable(boolean ampliable) {
		this.ampliable = ampliable;
	}

}
