package logica;
import java.io.*;
import java.util.*;

import javax.swing.JOptionPane;

public class Pedido {
	
	private List<Articulo> articulosPedido = null;
	
	public Pedido(){
		articulosPedido = new ArrayList<Articulo>();
	}
	
	public void add(Articulo articulo, int unidades){
		Articulo articuloEnPedido = null;
	
		for (Articulo a : articulosPedido){
			if (a.getCodigo().equals(articulo.getCodigo()))
				articuloEnPedido = a;
		}
		
		if (articuloEnPedido == null){
			articulo.setUnidades(unidades);
			articulosPedido.add(articulo);
		}
		else{
			int totalUnidades = articuloEnPedido.getUnidades() + unidades;
			articuloEnPedido.setUnidades(totalUnidades);
		}
	}
	
	public void remove(Articulo articulo, int unidades){
		
		for (Articulo a : articulosPedido){
			if (a.getCodigo().equals(articulo.getCodigo()))	{
				if(a.getUnidades()>=unidades){
				a.setUnidades(a.getUnidades()-unidades);}
				else{
					JOptionPane.showMessageDialog(null, "No existen tantas unidades para eliminar");	
				}}
			else{
				JOptionPane.showMessageDialog(null, "No se encuentran unidades compradas");
				}
				
		}
		
	}
	
public String generarCodigo(){
		
		String codigo ="";
		String base= "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int longitudCodigo = 10;
		for ( int i=0; i<longitudCodigo;i++){
			int numero = (int)(Math.random()*(base.length()));
			codigo += base.charAt(numero);
		}
		return codigo;
		
		
	}
	
	public float calcularTotalSinIva(){
		float total = 0.0f;
		
		for (Articulo a : articulosPedido){
			if(a.getUnidades()>=10){
				total += a.getPrecio()* a.getUnidades()*0.85;}
			else{
				total += a.getPrecio()* a.getUnidades();}
		}
		return total;
	}
	
	public void grabarPedido(String nombreFichero, String datos){
		try {
		        BufferedWriter fichero = new BufferedWriter(new FileWriter("files/" + nombreFichero + ".dat"));
		        String linea = datosPedido();
		        fichero.write(datos);
		        fichero.write(linea);		        
		        fichero.close();
			}

		catch (FileNotFoundException fnfe) {
		      System.out.println("El archivo no se ha podido guardar");
		    }
		catch (IOException ioe) {
		      new RuntimeException("Error de entrada/salida");
		}
	  }

	public void inicializar(){
		articulosPedido.clear();
	}

	public String datosPedido() {
		StringBuffer buffer = new StringBuffer();		
		for (Articulo a : articulosPedido)
			buffer.append( a.getDenominacion()+" - "+a.getPrecio()+ " \u20AC" + " - "+a.getUnidades()+ " unidades \n");
		return buffer.toString();
		
	}
	public List<Articulo> getArticulosPedido() {
		return articulosPedido;
	}
	
}

