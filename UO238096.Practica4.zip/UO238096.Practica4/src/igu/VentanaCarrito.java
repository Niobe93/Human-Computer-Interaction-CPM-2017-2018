package igu;


import javax.swing.JDialog;
import javax.swing.JScrollPane;

import logica.Articulo;

import java.awt.TextArea;

import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.ScrollPaneConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class VentanaCarrito extends JDialog {	
	
	private static final long serialVersionUID = 1L;
	private JScrollPane scrollPane;
	private JButton btnCerrar;
	private TextArea textArea;
	private VentanaPrincipal VP;
	
	public VentanaCarrito(VentanaPrincipal Vp) {
		
		this.VP = Vp;
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaCarrito.class.getResource("/img/logo.jpg")));
		setModal(true);
		setResizable(false);
		setBounds(100, 100, 450, 300);
		setTitle("Cesta de la compra");
		getContentPane().setLayout(null);
		getContentPane().add(getScrollPane());
		getContentPane().add(getBtnCerrar());
	}
	
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPane.setViewportBorder(null);
			scrollPane.setBounds(10, 11, 424, 223);
			scrollPane.setViewportView(getTextArea());
		}
		return scrollPane;
	}
	private JButton getBtnCerrar() {
		if (btnCerrar == null) {
			btnCerrar = new JButton("Cerrar");
			btnCerrar.setToolTipText("Cerrar el carrito");
			btnCerrar.setMnemonic('C');
			btnCerrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			btnCerrar.setBounds(345, 245, 89, 23);
		}
		return btnCerrar;
	}
	private TextArea getTextArea() {
		if (textArea == null) {
			textArea = new TextArea();
			textArea.setEditable(false);
			textArea.setBounds(0, 0, 432, 253);
			String articulosCarrito = "";
			for (Articulo articulo : (VP.getPedido().getArticulosPedido())) {
				articulosCarrito += "N�mero de unidades: " + 
									articulo.getUnidades() + "\t" + articulo.toString() +"\t" 
									+ VP.getPedido().calcularTotalSinIva()+ " \u20AC\n";
			}
			textArea.setText(articulosCarrito);
		}
		return textArea;
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	