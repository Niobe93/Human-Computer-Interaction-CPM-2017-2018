package igu;



import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class VentanaConfirmacion extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblOk;
	private JTextField textCodigo;
	private JLabel lblSuCdigo;
	private JButton btnFinalizar;
	private VentanaRegistro vr;
	private JTextField textTotalAPagar;
	private JLabel lblTotalAPagar;

	
	/**
	 * Create the frame.
	 */
	public VentanaConfirmacion(VentanaRegistro vr) {
		this.vr = vr;
		setTitle("Venta de accesorios: Confirmaci\u00F3n pedido");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaConfirmacion.class.getResource("/img/logo.jpg")));
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 431, 248);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblOk());
		contentPane.add(getTextCodigo());
		contentPane.add(getLblSuCdigo());
		contentPane.add(getBtnFinalizar());
		contentPane.add(getTextTotalAPagar());
		contentPane.add(getLblTotalAPagar());
	}

	public VentanaRegistro getVr() {
		return vr;
	}

	private JLabel getLblOk() {
		if (lblOk == null) {
			lblOk = new JLabel("Estamos procesando su pedido");
			lblOk.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblOk.setIcon(new ImageIcon(VentanaConfirmacion.class.getResource("/img/ok.png")));
			lblOk.setBounds(25, 11, 364, 85);
		}
		return lblOk;
	}
	private JTextField getTextCodigo() {
		if (textCodigo == null) {
			textCodigo = new JTextField();
			textCodigo.setToolTipText("C\u00F3digo a presentar para la recogida de su pedido en tienda.");
			textCodigo.setFont(new Font("Tahoma", Font.BOLD, 11));
			textCodigo.setText(vr.getVp().getPedido().generarCodigo());
			textCodigo.setEditable(false);
			textCodigo.setBounds(197, 107, 128, 20);
			textCodigo.setColumns(10);
		}
		return textCodigo;
	}
	private JLabel getLblSuCdigo() {
		if (lblSuCdigo == null) {
			lblSuCdigo = new JLabel("El c\u00F3digo de recogida es:");
			lblSuCdigo.setBounds(25, 96, 200, 50);
		}
		return lblSuCdigo;
	}
	private JButton getBtnFinalizar() {
		if (btnFinalizar == null) {
			btnFinalizar = new JButton("Finalizar");
			btnFinalizar.setToolTipText("Finalizar la compra.");
			btnFinalizar.setMnemonic('F');
			btnFinalizar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {					
					vr.getVp().getPedido().grabarPedido(textCodigo.getText(), vr.getDatosRegistro());
					vr.getVp().inicializar();
					vr.dispose();
					dispose();					
				}
			});
			btnFinalizar.setBounds(286, 172, 89, 23);
		}
		return btnFinalizar;
	}
	private JTextField getTextTotalAPagar() {
		if (textTotalAPagar == null) {
			textTotalAPagar = new JTextField();
			textTotalAPagar.setToolTipText("Total del importe de su pedido.");
			textTotalAPagar.setEditable(false);
			textTotalAPagar.setText(vr.getVp().getTotalAPagar());
			textTotalAPagar.setBounds(25, 161, 86, 20);
			textTotalAPagar.setColumns(10);
		}
		return textTotalAPagar;
	}
	private JLabel getLblTotalAPagar() {
		if (lblTotalAPagar == null) {
			lblTotalAPagar = new JLabel("Total a pagar:");
			lblTotalAPagar.setBounds(25, 145, 128, 14);
		}
		return lblTotalAPagar;
	}
	
	
}
 